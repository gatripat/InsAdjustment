The OpenShift `jbossews` cartridge documentation can be found at:

hosted at http://jbossews-nakulbhuwalka.rhcloud.com/api

example http://jbossews-nakulbhuwalka.rhcloud.com/api/dummy
