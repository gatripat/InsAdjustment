package com.barclays.cpapi.security;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.ehcache.EhCacheCacheManager;
import org.springframework.http.HttpStatus;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

public class RequestThrottlingInterceptor extends HandlerInterceptorAdapter {

	
	private static final Logger logger = Logger.getLogger(RequestThrottlingInterceptor.class);
	@Autowired
	private EhCacheCacheManager cacheManager;
	
	// Read the threshold value configured in the properties file 
	@Value("${thresholdvalue}")
    private int thresholdvalue;
	

	@Override
    public boolean preHandle(HttpServletRequest request, 
            HttpServletResponse response, Object handler)
        throws Exception {

		HttpSession httpSession = request.getSession();
		String sessionId = httpSession.getId();
				
		org.springframework.cache.Cache cache = cacheManager.getCache("rinsight");
		// Default initialization for first request
		int counter = 1;
		
		if(cache.get(sessionId) != null){
			counter = (Integer)cache.get(sessionId).get();
			counter++;			
		}
		cache.put(sessionId, counter);
		
		if(counter>=thresholdvalue){
			response.setStatus(HttpStatus.TOO_MANY_REQUESTS.value());
			logger.debug("SessionID: "+sessionId+" Number Requests given amount of time is: "+counter);
			return false;
			
		}
		logger.info("CounterID:   "+counter);
		
		return true;
    }
}
 