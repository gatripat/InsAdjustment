package com.barclays.cpapi.constants;

public interface ServiceProviderConstans {
	
	public static final String SERVICE_PROVIDER_CONTEXT_ROOT = "serviceProviderContextRoot";
	
}
