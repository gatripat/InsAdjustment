package com.barclays.cpapi.controller;

import java.net.UnknownHostException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.HandlerMapping;


/**
 * @author Srikanth
 *
 */
@RestController
@RequestMapping("/1.0")
public class ContentProviderController {
	
	
	// Read the service provider context root configured in properties file 
	@Value("${serviceProviderContextRoot}")
	private String spContextRoot;
	
	@Autowired
	RestTemplate restTemplate;
	
	
	@RequestMapping(method = RequestMethod.GET, value = "/**", produces = "application/json")
	@ResponseBody
	public String getRespoceFormServiceProvider(HttpServletRequest request) throws UnknownHostException {
		
		HttpEntity<?> entity = getEntity();
		String queryString = request.getQueryString();
		
		String pathOfTheUrl = (String) request
				.getAttribute(HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE);
		
		String cpURL = pathOfTheUrl;
		if(queryString!=null){
			 cpURL = pathOfTheUrl.concat("?"+queryString);
		}

//		String spContextRoot = env.getProperty(ServiceProviderConstans.SERVICE_PROVIDER_CONTEXT_ROOT);
		
		String spURL = cpURL.replace("/1.0/", spContextRoot);

		ResponseEntity<String>  result = restTemplate.exchange(spURL, HttpMethod.GET, entity, String.class);

		return result.getBody();
		
		
	}
	
	private HttpEntity<?> getEntity(){
		// Added for testing in apss server
		HttpHeaders headers = new HttpHeaders();
		headers.add("RequestorID", "Salesforce");
		headers.add("Proposition", "RelationShipInsight");
		headers.add("Widget", "Customer");
		headers.add("API", "getAccountDetails");

		HttpEntity<?> entity = new HttpEntity<Object>(headers);
		
		return entity;
	}

}
