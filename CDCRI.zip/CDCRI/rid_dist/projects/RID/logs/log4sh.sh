## log_location=${APP_HOME}/build/log/${src_id}.log
dat=`date +%F-%H%M` 
log_location=${1}_${dat}.log
#LOG4SH_CONFIGURATION="/apps/sbp_dev/build/lib/log/log4shnew.properties"
LOG4SH_CONFIGURATION='none'
 . ${LOG_HOME}/log4sh
## . ./log4sh
#. /home/nagendras/barclays_codebase/Hg7sC+ws/build/lib/log/log4sh
logger_setLevel INFO
logger_addAppenderWithPattern R '%d %p - %m%n'
appender_setType R RollingFileAppender
appender_file_setFile R $log_location
appender_file_setMaxFileSize R 50KB
appender_file_setMaxBackupIndex R 1
appender_activateOptions R
appender_setPattern R '%d %p - %m%n'
#LOG4SH_CONFIGURATION="/apps/sbp_dev/build/lib/log/log4shnew.properties"
#logger_addAppenderWithPattern appender '%d %p - %m%n'
#appender_activateOptions R
