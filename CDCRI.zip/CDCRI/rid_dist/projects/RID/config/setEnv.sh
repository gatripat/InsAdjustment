#Setup file

#MongoDB details
export IP_ADDRESS=slgdsr000002358.intranet.barcapint.com
export PORT=27017
export DB_NAME=test
export COLLECTION_NAME=account

#Teradata variable
export DATABASE_NAME=U_T_GCA_CORPORATE_PORTAL
export DATABASE_CONNECTION_URL=dwsoat.dws.barclays.co.uk
export DB_CONNECTION_T=jdbc:teradata://${DATABASE_CONNECTION_URL}/database=${DATABASE_NAME}
export DBUSERID_T=
export DBPASSWD_T=
export FILEFORMAT=textfile

#MAPPER
NUMMAPPER=1

#ORACLE connection string in development env
export DBUSERID=SOURCE_DEV
export DBPASSWD=sourcedev
export DB_CONNECTION=jdbc:oracle:thin:@INMBZP4099.in.dst.ibm.com:1521:SBPP

