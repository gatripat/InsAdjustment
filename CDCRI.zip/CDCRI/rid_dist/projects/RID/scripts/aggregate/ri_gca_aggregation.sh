#!/bin/bash
# Script Name - ri_gca_aggregation.sh
# Purpose - Used for aggregation for GCA source data


#kinit ${USER}@HADOOP.BARCLAYS.INTRANET -k -t ~/${USER}.keytab

# Export Application home directory
APP_HOME=/bigdata/projects/RI
CONF_DIR=$APP_HOME/config

# Source setup file - Environment variable
if [ -n "$APP_HOME" ]
then
    . $CONF_DIR/setEnv.sh
else
    echo "Application Direcotry not set" | logger_info
    exit 1
fi

# Source setup file - Application variable
if [ -n "$APP_HOME" ]
then
    . $CONF_DIR/setAppl.sh
    cd $SCRIPTS_DIR
else
    echo "Application Direcotry not set" | logger_info
    exit 1
fi

#Log file setup
if [ -f $LOG_HOME/log4sh.sh ]
then 
    . $LOG_HOME/log4sh.sh $LOG_HOME/
else 
    echo "LOG file directory not exist"
fi


# Exit with error if unset environments are found
set -u

SCRIPTNAME=`basename $0 .sh`

# Creating return value
iRet=0

# Getting Business date from the file(YYYY-MM-DD)
if [ -f $LOOKUP_DIR/prop_date ]
then 
    BUSINESS_DATE=`cat $LOOKUP_DIR/prop_date`
    echo "Business date of execution: $BUSINESS_DATE" | logger_info
else 
    echo "PROP file does not exist"
    exit 1
fi

# Spliting Business date into dd, mm, yy

yy=`echo ${BUSINESS_DATE}|cut -d '-' -f1`
mm=`echo ${BUSINESS_DATE}|cut -d '-' -f2`
dd=`echo ${BUSINESS_DATE}|cut -d '-' -f3`

# Calculating dates 12 and 36 months date period

ENDDATE_LAST_MONTH=`date -d "${BUSINESS_DATE}  -${dd} days" +%Y-%m-%d`
dd=`expr ${dd} - 1`
STARTDATE_12=`date -d "${BUSINESS_DATE}  -${dd} days -12 month" +%Y-%m-%d`
STARTDATE_36=`date -d "${BUSINESS_DATE}  -${dd} days -36 month" +%Y-%m-%d`

# Checking if RI aggregation has already executed for the passed Businedd date

if hadoop fs -test -e ${HDFS_RI_AGGR_GCA}/${BUSINESS_DATE};
then
    echo "RI aggregation already executed for business date ${BUSINESS_DATE} " | logger_info
    echo "Exiting from script with exit code 0" | logger_info 
else
    echo "BUSINESS_DATE- $BUSINESS_DATE"| logger_info
    echo "STARTDATE_12 - $STARTDATE_12"| logger_info
    echo "STARTDATE_36 - $STARTDATE_36"| logger_info
    echo "ENDDATE_LAST_MONTH - $ENDDATE_LAST_MONTH"| logger_info
    echo "DB_NAME - $DB_NAME"
    echo "COLLECTION_NAME - $COLLECTION_NAME"
    echo "IP_ADDRESS - $IP_ADDRESS"
    echo "PORT - $PORT"
    echo "RI aggregation -  ORG_DEMO -    hdfs://${ORG_DEMO}" | logger_info
    echo "RI aggregation -  CUST_ACCT -   hdfs://${CUST_ACCT}" | logger_info
    echo "RI aggregation -  ACCT_ATTRI -  hdfs://${ACCT_ATTRI}" | logger_info
    echo "RI aggregation -  DAILY_ACCT -  hdfs://${DAILY_ACCT}" | logger_info
    echo "RI aggregation -  REF_PROD -    hdfs://${REF_PROD}" | logger_info
    echo "RI aggregation -  ACCT_HIST -   hdfs://${ACCT_HIST}/${ENDDATE_LAST_MONTH}/part* "| logger_info
    echo "RI aggregation -  HDFS_RI_AGGR_GCA - hdfs://${HDFS_RI_AGGR_GCA}/${BUSINESS_DATE}"| logger_info

    #spark-submit --class RIAggregation --master yarn-cluster --executor-memory 1000M  --deploy-mode cluster  <jar file name> \
    #<prop date> <36 Month old start date> <12 Month old start date> <End date of last month> \
    #<Mongo DB name> <Mongo collection Name> <MongoDB host IP> <MongoDB port> \
    #<ORG_DEMO sparse active file> <CUST_ACCT sparse active file> <ACCT_ATTRI sparse active file> \
    #<DAILY_ACCT files generate in last 1 year> <REF_PROD file generate on prop date> \
    #<ACCT_HIST files containing last 36 month data> <output file name>

    spark-submit --class RIAggregation --master yarn-cluster --executor-memory 1000M  --deploy-mode cluster  ${JAR_DIR}/RIAggregation-assembly-1.0.jar \
    ${BUSINESS_DATE} ${STARTDATE_36} ${STARTDATE_12} ${ENDDATE_LAST_MONTH} \
    ${DB_NAME} ${COLLECTION_NAME} ${IP_ADDRESS} ${PORT} \
    hdfs://${ORG_DEMO} hdfs://${CUST_ACCT} hdfs://${ACCT_ATTRI} \
    hdfs://${DAILY_ACCT} hdfs://${REF_PROD} \
    hdfs://${ACCT_HIST}/${ENDDATE_LAST_MONTH}/part* hdfs://${HDFS_RI_AGGR_GCA}/${BUSINESS_DATE} 
    
    iRet=$?
    if [ $iRet -ne 0 ]
    then
        echo "Error in RI Aggregation : $iRet " | logger_info
        hadoop fs -rm -r ${HDFS_RI_AGGR_GCA}/${BUSINESS_DATE} 2>>/dev/null
        exit $iRet
    else

        ROWID=`date +%s%N`
        echo "put '${HBASE_SCOOP_LOG_RI}', '${ROWID}', '${HBASE_SCOOP_LOG_RI_CF}:RIAggregation_last_exec', '${BUSINESS_DATE}'"|hbase shell > $LOG_HOME/${SCRIPTNAME}_hbase_insert.log 

        iCount=`grep -c "0 row(s) in" $LOG_HOME/${SCRIPTNAME}_hbase_insert.log`
   
        if [ $iCount -eq 1 ]
        then
            echo "Date inserted in HBASE for table RIAggregation "| logger_info
        else
            echo "Failed to insert last run date in HBASE for table RIAggregation "| logger_info
            echo "Going to keep RIAggregation output but returing output status non zero" | logger_info
            exit 1
        fi
        echo "RI Aggregartion completed OK : $iRet"| logger_info
        exit $iRet
    fi
fi

