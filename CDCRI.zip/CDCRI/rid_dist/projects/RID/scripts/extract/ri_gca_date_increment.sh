#!/bin/bash
# Script Name - ri_gca_date_increment.sh
# Purpose - Used for date increment


#kinit ${USER}@HADOOP.BARCLAYS.INTRANET -k -t ~/${USER}.keytab

# Export Application home directory
APP_HOME=/bigdata/projects/RI
CONF_DIR=$APP_HOME/config

# Source setup file - Environment variable
if [ -n "$APP_HOME" ]
then
    . $CONF_DIR/setEnv.sh
else
    echo "Application Direcotry not set" | logger_info
    exit 1
fi

# Source setup file - Application variable
if [ -n "$APP_HOME" ]
then
    . $CONF_DIR/setAppl.sh
    cd $SCRIPTS_DIR
else
    echo "Application Direcotry not set" | logger_info
    exit 1
fi

#Log file setup
if [ -f $LOG_HOME/log4sh.sh ]
then 
    . $LOG_HOME/log4sh.sh $LOG_HOME/
else 
    echo "LOG file directory not exist"
fi

SCRIPTNAME=`basename $0 .sh`

# Parsing command line arguments
usage() { echo "Usage: $0 [-d <number of day to increment (optional)>]" 1>&2; exit 1; }
while getopts ":d:" o; do
    case "${o}" in
        d)
            dd=${OPTARG}
            ;;
        *)
            usage
            ;;
    esac
done

if [ -z "${dd}" ]; then
    echo "day value is not supplied.Default incrementing day by 1 " | logger_info
    dd=1
fi

re='^-?[0-9]+$'

if ! [[ $dd =~ $re ]] ; then
   echo "error: Input value is not a number" >&2; 
   usage
fi

# Getting Business date from the file(YYYY-MM-DD)
if [ -f $LOOKUP_DIR/prop_date ]
then 
    BUSINESS_DATE=`cat $LOOKUP_DIR/prop_date`
    echo "Current business date of execution: $BUSINESS_DATE" | logger_info
else 
    echo "PROP file does not exist"
    exit 1
fi

NEW_BUSINESS_DATE=`date -d "${BUSINESS_DATE}  ${dd} days " +%Y-%m-%d`

echo "New business date of execution: $NEW_BUSINESS_DATE" | logger_info
echo "$NEW_BUSINESS_DATE" >$LOOKUP_DIR/prop_date

exit 0
