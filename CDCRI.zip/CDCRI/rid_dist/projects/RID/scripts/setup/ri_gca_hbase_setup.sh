#!/bin/bash

#kinit ${USER}@HADOOP.BARCLAYS.INTRANET -k -t ~/${USER}.keytab

# Export Application home directory
APP_HOME=/bigdata/projects/RI
CONF_DIR=$APP_HOME/config

# Source setup file - Environment variable
if [ -n "$APP_HOME" ]
then
    . $CONF_DIR/setEnv.sh
else
    echo "Application Direcotry not set" | logger_info
    exit 1
fi

# Source setup file - Application variable
if [ -n "$APP_HOME" ]
then
    . $CONF_DIR/setAppl.sh
    cd $SCRIPTS_DIR
else
    echo "Application Direcotry not set" | logger_info
    exit 1
fi

if [ -f $LOG_HOME/log4sh.sh ]
then
    . $LOG_HOME/log4sh.sh $LOG_HOME/
else
    echo "LOG file directory not exist"
fi

# NameSpace will get it in dev/SIT/PROD env
echo "create_namespace '${HBASE_NAME_SPACE}' "|logger_info
echo "create_namespace '${HBASE_NAME_SPACE}' "|hbase shell

echo "create '${HBASE_SCOOP_LOG_RI}', {NAME => '${HBASE_SCOOP_LOG_RI_CF}'}"| logger_info

echo "create '${HBASE_SCOOP_LOG_RI}', {NAME => '${HBASE_SCOOP_LOG_RI_CF}'}"|hbase shell

