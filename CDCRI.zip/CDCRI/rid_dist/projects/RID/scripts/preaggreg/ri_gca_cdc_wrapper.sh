#!/bin/bash

#wrapper script for cdc day0 implementation of GCA
USER=`whoami`
echo $USER
kinit ${USER}@HADOOP.BARCLAYS.INTRANET -k -t ~/${USER}.keytab

# Export Application home directory
APP_HOME=/bigdata/projects/RI
CONF_DIR=$APP_HOME/config

prop_date=`cat $APP_HOME/lookup/prop_date`
SCRIPTNAME=`basename $0 .sh`

# Source setup file
if [ -n "$APP_HOME" ]
then
    
PROP_FILE=$CONF_DIR/setAppl.sh
 . $PROP_FILE
    echo $PROP_FILE
    source $PROP_FILE
    cd $SCRIPTS_DIR
else
    echo "Application Direcotry not set"
    exit 1
fi

timestamp=`date +%s`
log_file=${SCRIPTNAME}
if [ -f $LOG_HOME/log4sh.sh ]
then
    . $LOG_HOME/log4sh.sh $LOG_HOME/$log_file
else
    echo "LOG file directory not exist"
fi

echo ${SCRIPTNAME}|logger_info

table_name=$1

# Exit with error if unset environments are found
set -u

SCRIPTNAME=`basename $0 .sh`



# Source setup file
if [ -n "$table_name" ]
then
    echo "Table name" | logger_info
else
   echo "Table name not entered" | logger_info
    exit 2
fi

if hadoop fs -test -e $HDFS_RI_DATA_GCA/${table_name}_RID_HDP/sparse_history_retention/active/
then
  echo "Sparse retention hdfs dir exists" | logger_info
 else
echo "Creating Sparse retention hdfs dir" | logger_info
   hadoop fs -mkdir -p $HDFS_RI_DATA_GCA/${table_name}_RID_HDP/sparse_history_retention/active/
 fi   

#executing cdc implementation for day0 ,passing config file as an argument and table_name
#hadoop jar  build/libs/ri_gca_cdc-1.0.0.jar com.barclays.RI.gca.cdc.RiGcaCdcDay0 param CUSTOMER_ACCOUNT_LINK
LAST_EXEC_DATE=`echo "scan '${HBASE_SCOOP_LOG_RI}'"|hbase shell|grep ${table_name}_cdc_last_exec|tail -1|cut -d ' ' -f5|cut -d '=' -f2`
 is_valid=$?

#LAST_EXEC_DATE=`echo "scan '${HBASE_SCOOP_LOG_RI}', { COLUMNS => 'sources:${table_name}_cdc_last_exec'}"|hbase shell|tail -1|cut -d ' ' -f5|cut -d '=' -f2`

echo "last_exec_date" $LAST_EXEC_DATE

  if [ $is_valid -eq 0 ];
    then    
         hadoop jar  $JAR_DIR/ri_gca_cdc-1.0.0.jar com.barclays.rid.gca.cdc.RiGcaCdc $PROP_FILE  $table_name $PROP_DATE $LAST_EXEC_DATE
         is_valid=$?
  fi

  if [ $is_valid -eq 0 ];
    then
echo " hadoop fs -mv $HDFS_RI_DATA_GCA/${table_name}_RID_HDP/sparse_history/active/$LAST_EXEC_DATE $HDFS_RI_DATA_GCA/${table_name}_RID_HDP/sparse_history_retention/active/"| logger_info
    				   hadoop fs -mv $HDFS_RI_DATA_GCA/${table_name}_RID_HDP/sparse_history/active/$LAST_EXEC_DATE $HDFS_RI_DATA_GCA/${table_name}_RID_HDP/sparse_history_retention/active/| logger_info
						   
						   ROWID=`date +%s%N`
                           echo "put '${HBASE_SCOOP_LOG_RI}', '${ROWID}', '${HBASE_SCOOP_LOG_RI_CF}:${table_name}_cdc_last_exec', '${prop_date}'"|hbase shell

                                echo "Hbase fetch  executed successfully " | logger_info
  
else
echo "CDC implementation not executed successfully"| logger_error
fi

