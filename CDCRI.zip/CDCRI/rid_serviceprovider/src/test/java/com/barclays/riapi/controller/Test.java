package com.barclays.riapi.controller;

import org.springframework.web.client.RestTemplate;

import com.barclays.riapi.model.Customer;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		RestTemplate restTemplate = new RestTemplate();
    	Customer customer = restTemplate.getForObject("https://9.118.8.103:8443/rinsight/api/customer/501?productLevel1=DEBT ", Customer.class);
    	System.out.println(customer);

	}

}
