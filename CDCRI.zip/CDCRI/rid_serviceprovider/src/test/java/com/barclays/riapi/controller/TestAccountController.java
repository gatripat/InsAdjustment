package com.barclays.riapi.controller;
/*package jcom.barclays.riapi.controller;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
//import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations=("classpath:serviceprovider-servlet.xml"))
@WebAppConfiguration
public class TestAccountController {

    @Autowired 
    WebApplicationContext wac;
    private MockMvc mockMvc;
    
    @Before
    public void setup() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac).build();
    }
    
    // Monthlystats
    
    @Test
    public void TestGetAccountMonthlystatsByAccountID(){
    	try {
    		
//			this.mockMvc.perform(MockMvcRequestBuilders.post("/api/accounts/monthlyStats/{accountID}", "228857511")).andExpect(MockMvcResultMatchers.status().isOk());
//    		this.mockMvc.perform(MockMvcRequestBuilders.get("/1.0/accounts/monthlyStats/{accountID}", "228857511")).
//    		andExpect(MockMvcResultMatchers.status().isOk());
//    		andExpect(MockMvcResultMatchers.jsonPath("$[0].accountID").value(228857511)).
//    		andExpect(MockMvcResultMatchers.jsonPath("$[0].monthlyAverage.$[0].key").value("2015"));
		} catch (Exception e) {
			e.printStackTrace();
		}
    	
    }

    @Test
    public void testAccountDetails(){
    	String url = "http://localhost:8000/serviceprovider/1.0/customer/501?productLevel1=DEBT";
    	RestTemplate restTemplate = new RestTemplate();
    	
    	//Preparing header information
    	HttpHeaders headers = new HttpHeaders();
    	headers.add("IP", "9.118.8.103");
        headers.add("username", "Hello");
        headers.add("password", "Hello123");
        
        headers.add("RequestorID", "Salesforce122121");
        headers.add("Proposition", "RelationShipInsight");
        headers.add("Widget", "Customer");
        headers.add("API", "getAccountDetails");
                
        headers.setContentType(MediaType.APPLICATION_JSON);
//    	headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));

    	HttpEntity<?> entity = new HttpEntity<Object>(headers);
//    	URI uri = restTemplate.postForLocation(url, HttpMethod.POST, entity);    	
//    	List<Account> account = restTemplate.getForObject(url, Account.class);
    	
    	ResponseEntity<List<Account>> accountResult = restTemplate.exchange(url, HttpMethod.GET, entity, 
				new ParameterizedTypeReference<List<Account>>(){});
    	
		
    	
    	System.out.println("Account..."+accountResult.getBody());
    	
    }
	
}
*/