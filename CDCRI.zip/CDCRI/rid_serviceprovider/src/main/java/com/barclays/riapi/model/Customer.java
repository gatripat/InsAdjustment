package com.barclays.riapi.model;


/**
 * @author Srikanth
 * 
 */
public class Customer {

	private Integer customerID;
	private String customerName;
//	private Long effectiveStartDate;
//	private Long effectiveEndDate; removed in new json
	
	public Integer getCustomerID() {
		return customerID;
	}

	public void setCustomerID(Integer customerID) {
		this.customerID = customerID;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	@Override
	public String toString() {
		return "Customer [customerID=" + customerID + ", customerName="
				+ customerName + "]";
	}

}
