package com.barclays.riapi.model;

/**
 * @author IBM
 * 
 */
public class Dailystats {

	
	private Long date;
	private Double balance;
//	private Double usage; removed in new json
	
	public Long getDate() {
		return date;
	}

	public void setDate(Long date) {
		this.date = date;
	}

	public Double getBalance() {
		return balance;
	}

	public void setBalance(Double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Dailystats [date=" + date + ", balance=" + balance + "]";
	}
	
}
