package com.barclays.riapi.aspect;

import org.apache.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;


@Aspect
public class LoggingAspect {
	
	private static final Logger logger = Logger.getLogger(LoggingAspect.class);
	
	@Before("execution(* com.barclays.riapi.controller.*.*(..)) || execution(* com.barclays.riapi.security.*.*(..))")
	public void logBefore(JoinPoint joinPoint) {
		logger.info("Starting: " + joinPoint.getTarget().getClass()+ "." + joinPoint.getSignature().getName() + "()");
	}
	
	@After("execution(* com.barclays.riapi.controller.*.*(..)) || execution(* com.barclays.riapi.security.*.*(..))")
	public void logAfter(JoinPoint joinPoint) {
		logger.info("Ending: " + joinPoint.getTarget().getClass()+ "." + joinPoint.getSignature().getName() + "()");

	}
	
	@AfterReturning(
			pointcut = "execution(* com.barclays.riapi.controller.*.*(..)) || execution(* com.barclays.riapi.security.*.*(..))",
			returning= "result")
	public void logAfterReturning(JoinPoint joinPoint, Object result) {
		logger.info("Returning: " + joinPoint.getTarget().getClass()+ "." + joinPoint.getSignature().getName() + "()");
		logger.debug("Result: "+ result);
	}
	
	 @AfterThrowing(
		      pointcut = "execution(* com.barclays.riapi.controller.*.*(..)) || execution(* com.barclays.riapi.security.*.*(..))",
		      throwing= "error")
	 public void logAfterThrowing(JoinPoint joinPoint, Throwable error) {
		 logger.info("Thrwoing Exception: " + joinPoint.getTarget().getClass()+ "." + joinPoint.getSignature().getName() + "()");
		 logger.error("Exception: "+ error);
	 }
	 
	/* @Around("execution(* com.barclays.riapi.controller.*.*(..))")
	 public void logAround(ProceedingJoinPoint joinPoint) throws Throwable {
		 logger.info("Around: "+joinPoint.getSignature().getName());
	 }*/

}
