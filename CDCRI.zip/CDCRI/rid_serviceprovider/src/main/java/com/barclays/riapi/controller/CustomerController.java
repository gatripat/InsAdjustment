package com.barclays.riapi.controller;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.aggregation.TypedAggregation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.http.HttpEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.barclays.riapi.model.Account;


/**
 * @author srikanth
 *
 */
@RestController
@RequestMapping("/1.0")
public class CustomerController {

	@Autowired
	private MongoTemplate mongoTemplate;
	
	@Autowired
	private Environment env;
	
	// Read the Overdraft Product code list from properties and file path configured in jboss server 
	@Value("${productid}")
    private String productIDs;
	
	private static final Logger logger = Logger.getLogger(CustomerController.class);
	@RequestMapping(method = RequestMethod.GET, value = "/customer/{customerID}")
	public List<Account> getAccountDetailsByCustID(@PathVariable Integer customerID,
			@RequestParam(value="productLevel1", required=true) String productLevel1,
			@RequestParam(name="page",required=false) Integer page,
			@RequestParam(name="limit",required=false) Integer limit,
			HttpEntity<?> requestEntity) throws UnknownHostException {

		
		//getting header information from the UI
		logger.info("Username: "+requestEntity.getHeaders().get("username"));
		
		List<AggregationOperation> paggOperations = new ArrayList<AggregationOperation>();
//			paggOperations.add(Aggregation.unwind("products"));
		paggOperations.add(Aggregation.match(Criteria.where("customer.customerID").is(customerID)));
		paggOperations.add(Aggregation.match(Criteria.where("product.productLevel1").is(productLevel1)));
		paggOperations.add(Aggregation.project("customer","product", "dailystats").andInclude("sortCode","accountNumber",
				"accountID","accountName","currency","balance","limit","rate","maturity"));
		
		if(page!=null&&limit!=null){
			paggOperations.add(Aggregation.skip((page-1)*limit));
			paggOperations.add(Aggregation.limit(limit));
		}
//		    paggOperations.add(Aggregation.sort(Sort.Direction.DESC,"effectiveEndDate"));
	    TypedAggregation<Account> paggregation = Aggregation.newAggregation(Account.class, paggOperations);
	    
	    AggregationResults<Account> paggResults = mongoTemplate.aggregate(paggregation, Account.class, Account.class);
		
	    List<Account> accounts = paggResults.getMappedResults();
	    
        // if the product code is exist in the product list set overdraft flag is "Y"
        if(productIDs!=null){
        	String[] productList = productIDs.split(",");
     		List<String> productIDList = Arrays.asList(productList);
     		if(!accounts.isEmpty()){
     			for(Account account : accounts){
     				String productID = String.valueOf(account.getProduct().getProductId());
     				if(productIDList.contains(productID)){
     					account.setOverdraft("Y");
     				}else{
     					account.setOverdraft("N");
     				}
     			}
     		}
        }
		return accounts;
		
	}
}
