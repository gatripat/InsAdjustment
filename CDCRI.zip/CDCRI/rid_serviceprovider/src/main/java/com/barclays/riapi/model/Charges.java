package com.barclays.riapi.model;

import java.util.List;

/**
 * @author srikanth
 * 
 */
public class Charges {
	
	private Long date;
	private Integer accountID;
	private String tariff;
	private String tariffOk;
	private String currency;
	private List<ChargesValues> values;
	
	public Long getDate() {
		return date;
	}
	public void setDate(Long date) {
		this.date = date;
	}
	public Integer getAccountID() {
		return accountID;
	}
	public void setAccountID(Integer accountID) {
		this.accountID = accountID;
	}
	public String getTariff() {
		return tariff;
	}
	public void setTariff(String tariff) {
		this.tariff = tariff;
	}
	public String getTariffOk() {
		return tariffOk;
	}
	public void setTariffOk(String tariffOk) {
		this.tariffOk = tariffOk;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public List<ChargesValues> getValues() {
		return values;
	}
	public void setValues(List<ChargesValues> values) {
		this.values = values;
	}
	
	@Override
	public String toString() {
		return "Charges [date=" + date + ", accountID=" + accountID
				+ ", tariff=" + tariff + ", tariffOk=" + tariffOk
				+ ", currency=" + currency + ", values=" + values + "]";
	}	

}
