package com.barclays.riapi.model;


/**
 * @author IBM
 * 
 */
public class Monthlystats {

	private Long date;
//	private Integer month;
	private Double avgBalance;
	private Double worstBalance;
	
	public Long getDate() {
		return date;
	}
	public void setDate(Long date) {
		this.date = date;
	}
	public Double getAvgBalance() {
		return avgBalance;
	}
	public void setAvgBalance(Double avgBalance) {
		this.avgBalance = avgBalance;
	}
	public Double getWorstBalance() {
		return worstBalance;
	}
	public void setWorstBalance(Double worstBalance) {
		this.worstBalance = worstBalance;
	}
	@Override
	public String toString() {
		return "Monthlystats [date=" + date + ", avgBalance=" + avgBalance
				+ ", worstBalance=" + worstBalance + "]";
	}
		
}
