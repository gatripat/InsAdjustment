
package com.barclays.riapi.model;


public class TurnoverValues {

    private Integer year;
    private Integer value;
    private String projected;
    private Integer projectedValue;
    
	public Integer getYear() {
		return year;
	}
	public void setYear(Integer year) {
		this.year = year;
	}
	public Integer getValue() {
		return value;
	}
	public void setValue(Integer value) {
		this.value = value;
	}
	public String getProjected() {
		return projected;
	}
	public void setProjected(String projected) {
		this.projected = projected;
	}
	public Integer getProjectedValue() {
		return projectedValue;
	}
	public void setProjectedValue(Integer projectedValue) {
		this.projectedValue = projectedValue;
	}
	
	@Override
	public String toString() {
		return "TurnoverValues [year=" + year + ", value=" + value
				+ ", projected=" + projected + ", projectedValue="
				+ projectedValue + "]";
	}
    
	
}
