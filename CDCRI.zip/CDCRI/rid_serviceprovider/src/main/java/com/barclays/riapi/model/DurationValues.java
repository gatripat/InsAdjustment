package com.barclays.riapi.model;

public class DurationValues {

	private Integer cashPayments;
	private Integer electronicPayments;
	private Integer monthlyFee;
	private Integer cheques;
	private Integer others;
	
	public Integer getCashPayments() {
		return cashPayments;
	}
	public void setCashPayments(Integer cashPayments) {
		this.cashPayments = cashPayments;
	}
	public Integer getElectronicPayments() {
		return electronicPayments;
	}
	public void setElectronicPayments(Integer electronicPayments) {
		this.electronicPayments = electronicPayments;
	}
	public Integer getMonthlyFee() {
		return monthlyFee;
	}
	public void setMonthlyFee(Integer monthlyFee) {
		this.monthlyFee = monthlyFee;
	}
	public Integer getCheques() {
		return cheques;
	}
	public void setCheques(Integer cheques) {
		this.cheques = cheques;
	}
	public Integer getOthers() {
		return others;
	}
	public void setOthers(Integer others) {
		this.others = others;
	}
	
	@Override
	public String toString() {
		return "DurationValues [cashPayments=" + cashPayments
				+ ", electronicPayments=" + electronicPayments
				+ ", monthlyFee=" + monthlyFee + ", cheques=" + cheques
				+ ", others=" + others + "]";
	}
	
	
	
}
