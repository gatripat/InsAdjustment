
package com.barclays.riapi.model;

import java.util.List;


public class Turnover {

    private Integer accountID;
    private Integer accountNumber;
    private Integer comparison;
    private String comparisonPercent;
    private String currency;
    private List<TurnoverValues> values;
    
	public Integer getAccountID() {
		return accountID;
	}
	public void setAccountID(Integer accountID) {
		this.accountID = accountID;
	}
	public Integer getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(Integer accountNumber) {
		this.accountNumber = accountNumber;
	}
	public Integer getComparison() {
		return comparison;
	}
	public void setComparison(Integer comparison) {
		this.comparison = comparison;
	}
	public String getComparisonPercent() {
		return comparisonPercent;
	}
	public void setComparisonPercent(String comparisonPercent) {
		this.comparisonPercent = comparisonPercent;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public List<TurnoverValues> getValues() {
		return values;
	}
	public void setValues(List<TurnoverValues> values) {
		this.values = values;
	}
	
	@Override
	public String toString() {
		return "Turnover [accountID=" + accountID + ", accountNumber="
				+ accountNumber + ", comparison=" + comparison
				+ ", comparisonPercent=" + comparisonPercent + ", currency="
				+ currency + ", values=" + values + "]";
	}
    
}
