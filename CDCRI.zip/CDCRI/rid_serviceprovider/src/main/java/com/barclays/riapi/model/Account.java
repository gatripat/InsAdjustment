package com.barclays.riapi.model;

import java.util.List;

public class Account {

	
	private String sortCode;
	private String accountNumber;
	private Long accountID;
	private String accountName;
	private String currency; 
	private Double balance;
	private String limit;
	private String rate;
	private String maturity;
	private String overdraft;
	private Customer customer;
	private Product product;
	private FacilitiesUsageStats facilitiesUsageStats;
	private Dailystats dailystats;
	private List<Monthlystats> monthlyAverages;
	
	public String getSortCode() {
		return sortCode;
	}
	public void setSortCode(String sortCode) {
		this.sortCode = sortCode;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public Long getAccountID() {
		return accountID;
	}
	public void setAccountID(Long accountID) {
		this.accountID = accountID;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public Double getBalance() {
		return balance;
	}
	public void setBalance(Double balance) {
		this.balance = balance;
	}
	public String getLimit() {
		return limit;
	}
	public void setLimit(String limit) {
		this.limit = limit;
	}
	public String getRate() {
		return rate;
	}
	public void setRate(String rate) {
		this.rate = rate;
	}
	public String getMaturity() {
		return maturity;
	}
	public void setMaturity(String maturity) {
		this.maturity = maturity;
	}
	public String getOverdraft() {
		return overdraft;
	}
	public void setOverdraft(String overdraft) {
		this.overdraft = overdraft;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public FacilitiesUsageStats getFacilitiesUsageStats() {
		return facilitiesUsageStats;
	}
	public void setFacilitiesUsageStats(FacilitiesUsageStats facilitiesUsageStats) {
		this.facilitiesUsageStats = facilitiesUsageStats;
	}
	public Dailystats getDailystats() {
		return dailystats;
	}
	public void setDailystats(Dailystats dailystats) {
		this.dailystats = dailystats;
	}
	public List<Monthlystats> getMonthlyAverages() {
		return monthlyAverages;
	}
	public void setMonthlyAverages(List<Monthlystats> monthlyAverages) {
		this.monthlyAverages = monthlyAverages;
	}
	
	@Override
	public String toString() {
		return "Account [sortCode=" + sortCode + ", accountNumber="
				+ accountNumber + ", accountID=" + accountID + ", accountName="
				+ accountName + ", currency=" + currency + ", balance="
				+ balance + ", limit=" + limit + ", rate=" + rate
				+ ", maturity=" + maturity + ", overdraft=" + overdraft
				+ ", customer=" + customer + ", product=" + product
				+ ", facilitiesUsageStats=" + facilitiesUsageStats
				+ ", dailystats=" + dailystats + ", monthlyAverages="
				+ monthlyAverages + "]";
	}	
	
}
