package com.barclays.riapi.model;

import java.util.List;

/**
 * @author srikanth
 * 
 */
public class ChargesValues {

	private Integer duration;
	private List<DurationValues> values;
	private Integer total;
	
	public Integer getDuration() {
		return duration;
	}
	public void setDuration(Integer duration) {
		this.duration = duration;
	}
	public List<DurationValues> getValues() {
		return values;
	}
	public void setValues(List<DurationValues> values) {
		this.values = values;
	}
	public Integer getTotal() {
		return total;
	}
	public void setTotal(Integer total) {
		this.total = total;
	}
	
	@Override
	public String toString() {
		return "ChargesValues [duration=" + duration + ", values=" + values
				+ ", total=" + total + "]";
	}

	
}
