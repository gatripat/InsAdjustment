package com.barclays.riapi.controller;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.aggregation.TypedAggregation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.barclays.riapi.model.Account;
import com.barclays.riapi.model.Charges;
import com.barclays.riapi.model.Turnover;

/**
 * @author Srikanth
 *
 */
@RestController
@RequestMapping("/1.0")
public class AccountController {
	

	
	@Autowired
	private MongoTemplate mongoTemplate;
	
	private static final Logger logger = Logger.getLogger(AccountController.class);
	
	// Overdraft Usage
	@RequestMapping(method = RequestMethod.GET, value = "/accounts/overdraftUsage/{accountID}")
	public Account getAccountOverdraftUsageByAccountID(@PathVariable Integer accountID) throws UnknownHostException {

		logger.debug("getAccountOverdraftUsageByAccountID is started with accountID: "+accountID);
		List<AggregationOperation> paggOperations = new ArrayList<AggregationOperation>();
		paggOperations.add(Aggregation.match(Criteria.where("accountID").is(accountID)));
		paggOperations.add(Aggregation.unwind("monthlyAverages"));
		 paggOperations.add(Aggregation.sort(Sort.Direction.DESC,"monthlyAverages.date"));
		 paggOperations.add(Aggregation.limit(12));
		 paggOperations.add(Aggregation.group("accountID","accountNumber","sortCode","dailystats","facilitiesUsageStats","limit","rate","maturity").push(
				 "monthlyAverages").as("monthlyAverages"));
		 
		paggOperations.add(Aggregation.project("accountID","accountNumber","sortCode","dailystats","facilitiesUsageStats","limit","rate","maturity","monthlyAverages"));
				
//	    paggOperations.add(Aggregation.sort(Sort.Direction.DESC,"effectiveEndDate"));
	    TypedAggregation<Account> paggregation = Aggregation.newAggregation(Account.class, paggOperations);
	    
	    
	    AggregationResults<Account> paggResults = mongoTemplate.aggregate(paggregation, Account.class, Account.class);
		
		List<Account> accounts = paggResults.getMappedResults();

		Account account = new Account();
		if(!accounts.isEmpty()){
			account = accounts.get(0);
		}
		return account;
	}
	
	// Monthlystats
	@RequestMapping(method = RequestMethod.GET, value = "/accounts/monthlyStats/{accountID}")
	public Account getAccountMonthlystatsByAccountID(@PathVariable Integer accountID) throws UnknownHostException {
		logger.debug("getAccountMonthlystatsByAccountID is started with accountID: "+accountID);
		List<AggregationOperation> paggOperations = new ArrayList<AggregationOperation>();
		paggOperations.add(Aggregation.match(Criteria.where("accountID").is(accountID)));
		paggOperations.add(Aggregation.project("accountID","accountNumber","sortCode","monthlyAverages"));
				
//	    paggOperations.add(Aggregation.sort(Sort.Direction.DESC,"effectiveEndDate"));
	    TypedAggregation<Account> paggregation = Aggregation.newAggregation(Account.class, paggOperations);
	    
	    AggregationResults<Account> paggResults = mongoTemplate.aggregate(paggregation, Account.class, Account.class);
		
		List<Account> accounts = paggResults.getMappedResults();
		Account account = new Account();
		if(!accounts.isEmpty()){
			account = accounts.get(0);
		}
		return account;
	}
	
	// Charges
		@RequestMapping(method = RequestMethod.GET, value = "/accounts/charges/{accountID}")
		public List<Charges> findByChargesAccountID(@PathVariable Integer accountID, 
				@RequestParam(value="duration", required=true) Integer duration) throws UnknownHostException {
			List<AggregationOperation> list = new ArrayList<AggregationOperation>();
			list.add(Aggregation.match(Criteria.where("accountID").is(accountID)));
		    list.add(Aggregation.unwind("values"));
		    list.add(Aggregation.match(Criteria.where("values.duration").is(duration)));
		    list.add(Aggregation.group("date","accountID","tariff","tariffOk","currency").push("values").as("values"));
		    list.add(Aggregation.project("date","accountID","tariff","tariffOk","currency","values")); 

			TypedAggregation<Charges> agg = Aggregation.newAggregation(Charges.class, list);
		    AggregationResults<Charges> results = mongoTemplate.aggregate(agg, Charges.class, Charges.class); 

		    return results.getMappedResults();
		}
		
		// Turnover API
		@RequestMapping(method = RequestMethod.GET, value = "/accounts/turnover/{accountID}")
		public List<Turnover> findTurnoverByAccountID(@PathVariable Integer accountID){		
			List<AggregationOperation> list = new ArrayList<AggregationOperation>();
			list.add(Aggregation.match(Criteria.where("accountID").is(accountID)));

			TypedAggregation<Turnover> agg = Aggregation.newAggregation(Turnover.class, list);
		    AggregationResults<Turnover> results = mongoTemplate.aggregate(agg, Turnover.class, Turnover.class); 

		    return results.getMappedResults();
		}
	

}
