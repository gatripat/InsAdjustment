package com.barclays.riapi.security;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.barclays.riapi.controller.CustomerController;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;

public class RestAuthorizationInterceptor extends HandlerInterceptorAdapter {

	@Autowired
	private MongoTemplate mongoTemplate;	
	
	private static final Logger logger = Logger.getLogger(CustomerController.class);

	@Override
    public boolean preHandle(HttpServletRequest request, 
            HttpServletResponse response, Object handler)
        throws Exception {

	String RequestorID = request.getHeader("RequestorID");
	String proposition = request.getHeader("Proposition");
	String widget = request.getHeader("Widget");
	String api = request.getHeader("API");
	
	BasicDBObject whereQuery = new BasicDBObject();
	whereQuery.put("RequestorID", RequestorID);
	whereQuery.put("WidgetList.Proposition", proposition);
	whereQuery.put("WidgetList.Widget", widget);
	whereQuery.put("WidgetList.API", api);    
    
//	Query query = Query.query(Criteria.where("WidgetList.Proposition").is(
//			proposition));
//	boolean result = mongoTemplate.exists(query, "entitlements");
	
	DBCollection dbcoll = mongoTemplate.getCollection("entitlements");
	
	DBCursor result = dbcoll.find(whereQuery);
	if(!result.hasNext()){
		response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
		logger.error("Error Code : "+HttpServletResponse.SC_UNAUTHORIZED);
		return false;
	} else{
		return true;
	}
	
    }
}
 