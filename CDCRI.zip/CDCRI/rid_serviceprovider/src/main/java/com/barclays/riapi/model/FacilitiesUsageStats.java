package com.barclays.riapi.model;

/**
 * @author IBM
 * 
 */
public class FacilitiesUsageStats {

	private Long date;
	private Double maxUsed;
//	private Integer minUsed;
	private Integer avgDays;
	private Integer odDays;
	private Long calculatedOnDate;
	
	public Long getDate() {
		return date;
	}
	public void setDate(Long date) {
		this.date = date;
	}
	public Double getMaxUsed() {
		return maxUsed;
	}
	public void setMaxUsed(Double maxUsed) {
		this.maxUsed = maxUsed;
	}
	public Integer getAvgDays() {
		return avgDays;
	}
	public void setAvgDays(Integer avgDays) {
		this.avgDays = avgDays;
	}
	public Integer getOdDays() {
		return odDays;
	}
	public void setOdDays(Integer odDays) {
		this.odDays = odDays;
	}
	public Long getCalculatedOnDate() {
		return calculatedOnDate;
	}
	public void setCalculatedOnDate(Long calculatedOnDate) {
		this.calculatedOnDate = calculatedOnDate;
	}
	
	@Override
	public String toString() {
		return "FacilitiesUsageStats [date=" + date + ", maxUsed=" + maxUsed
				+ ", avgDays=" + avgDays + ", odDays=" + odDays
				+ ", calculatedOnDate=" + calculatedOnDate + "]";
	}	
	
		
}
