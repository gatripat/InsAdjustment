package com.barclays.riapi.model;

import org.springframework.data.mongodb.core.mapping.Field;

public class Values {

	@Field
	private Integer month;
	@Field
	private double avgBalance;
	@Field
	private double worstBalance;

	public Integer getMonth() {
		return month;
	}

	public void setMonth(Integer month) {
		this.month = month;
	}

	public double getAvgBalance() {
		return avgBalance;
	}

	public void setAvgBalance(double avgBalance) {
		this.avgBalance = avgBalance;
	}

	public double getWorstBalance() {
		return worstBalance;
	}

	public void setWorstBalance(double worstBalance) {
		this.worstBalance = worstBalance;
	}

	@Override
	public String toString() {
		return "Values [month=" + month + ", avgBalance=" + avgBalance
				+ ", worstBalance=" + worstBalance + "]";
	}

}
