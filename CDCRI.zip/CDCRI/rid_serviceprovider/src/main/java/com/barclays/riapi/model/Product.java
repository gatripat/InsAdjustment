package com.barclays.riapi.model;

/**
 * @author IBM
 * 
 */
public class Product {

	private String productName;
	private Integer productID;
	private String productLevel1;
	private String productLevel2;
	private String productLevel3;
	
	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Integer getProductId() {
		return productID;
	}

	public void setProductId(Integer productID) {
		this.productID = productID;
	}

	public String getProductLevel1() {
		return productLevel1;
	}

	public void setProductLevel1(String productLevel1) {
		this.productLevel1 = productLevel1;
	}

	public String getProductLevel2() {
		return productLevel2;
	}

	public void setProductLevel2(String productLevel2) {
		this.productLevel2 = productLevel2;
	}

	public String getProductLevel3() {
		return productLevel3;
	}

	public void setProductLevel3(String productLevel3) {
		this.productLevel3 = productLevel3;
	}


	@Override
	public String toString() {
		return "Product [productName=" + productName + ", productId="
				+ productID + ", productLevel1=" + productLevel1
				+ ", productLevel2=" + productLevel2 + ", productLevel3="
				+ productLevel3 + ", accounts="  + "]";
	}

}
