package com.barclays.rid

import org.apache.spark._
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Calendar
import org.apache.hadoop.conf.Configuration
import com.mongodb.DBObject
import com.mongodb.BasicDBObjectBuilder
import com.mongodb.DBCollection
import com.mongodb.MongoClient
import com.mongodb.BasicDBObject
import com.mongodb.DBObject
import com.mongodb.MongoClientURI
import java.util.ArrayList
import org.apache.hadoop.security.UserGroupInformation
import org.apache.hadoop.security.UserGroupInformation.AuthenticationMethod
import sys.process._


object  RIAggregation {
  
   def  main(args: Array[String]) {
    
    val conf = new SparkConf().setAppName("RIAggregation").setMaster("yarn-cluster")
	val sc = new SparkContext(conf)
	
	val sdf = new SimpleDateFormat("yyyy-MM-dd")
	
	val ProcDate=sdf.parse(args(0)) //YYYY-MM-DD
	val StartDate_36=sdf.parse(args(1)) //YYYY-MM-DD
	val StartDate_12=sdf.parse(args(2)) //YYYY-MM-DD
	val EndDate_12=sdf.parse(args(3)) //YYYY-MM-DD
	val DBName = args(4) //MongoDB database Name
	val Collection = args(5) //MongoDB collection name
	val IP_Address = args(6) //MogoDB ip address
	val Port = args(7).toInt //MongoDB port
	val OrgDemo = args(8) //ORGANISATION_DEMOGRAPHY_RID sparse active file
	val CustAcct = args(9) //CUSTOMER_ACCOUNT_LINK_RID sparse active file
	val AcctAttri = args(10) //ACCOUNT_ATTRIBUTES_RID sparse active file
	val DailyAcct=args(11) //DAILY_ACCOUNT_BALANCE_RID extract files
	val Refproduct = args(12) //REF_PRODUCT_HIERARCHY_RID extract files
	val AcctHist=args(13) //ACCOUNT_HISTORICAL_DATA_RID extract files
	val RiAggregate=args(14) //RI Aggregate output file
	//val uri=args(15) // RI mongo uri
	//val tktfile = args(20)
	
	val OrgDemoLines = sc.textFile(OrgDemo)
	val CustAcctLines = sc.textFile(CustAcct)
	val AcctAttrLines = sc.textFile(AcctAttri)
	val DailyAcctLines = sc.textFile(DailyAcct)
	val RefproductLines = sc.textFile(Refproduct)
	val AcctHistLines = sc.textFile(AcctHist)
	
	//sc.addFile(tktfile)
	
	val cal = Calendar.getInstance();
	cal.setTime(ProcDate);
	
	cal.add(Calendar.DATE, -30);
	val dateBefore30Days = cal.getTime();
	//val partition = new HashPartitioner(2)

	//Getting current time in milliseconds	
	cal.setTime(ProcDate)
	val ProcDateTimestamp = cal.getTimeInMillis()
	
	//Reading data from file - ORGANISATION_DEMOGRAPHY_RID
	//Output - CUSTOMER_ID,CUSTOMER_NAME	   
	val OrgDemoList = OrgDemoLines.map(_.split("\\|")).map(a=>List(a(1),a(3).toString.trim()))
	
	//Reading data from file - CUSTOMER_ACCOUNT_LINK_RID
	//Output - CUSTOMER_ID,ACCOUNT_ID,CURRENCY_CODE,MATURITY_DATE
	val CustAcctList = CustAcctLines.map(_.split("\\|")).map(a=>List(a(1),a(2),a(5).toString.trim(),a(8).toString.trim()))
	
	//Reading data from file - ACCOUNT_ATTRIBUTES_RID
	//Output - ACCOUNT_ID,ACCOUNT_NAME,ACCOUNT_NUMBER,ACCOUNT_SORT_CODE
	val AcctAttrList = AcctAttrLines.map(_.split("\\|")).map(a=>List(a(1),a(2).toString.trim,a(3), a(7).toString.trim()))
	
	//Reading data from file - DAILY_ACCOUNT_BALANCE_RID
	//output - ACCOUNT_ID,PRODUCT_IDENTIFIER,SUMMARY_DATE,BALANCE_AMT,LIMIT_AMT,PRODUCT_RATE,SRCTYPE
	//val DailyAcctList = DailyAcctLines.map(_.split("\\|")).map(a=>List(a(1).toString,a(4).toString,a(2).toString.trim,a(3).toString.trim(),a(6),if (a(7).compareTo("null") ==0 ) "null" else (((a(7).toFloat*(1000))).toInt).toString,a(8).trim()))
	val DailyAcctList = DailyAcctLines.map(_.split("\\|")).map(a=>List(a(1).toString,a(4).toString,a(2).toString.trim,a(3).toString.trim(),a(6),a(7),a(8).trim()))
		
	//Reading data from file - REF_PRODUCT_HIERARCHY_RID
	//Output - PRODUCT_IDENTIFIER,PRODUCT_NAME,PRODUCT_LEVEL_1,PRODUCT_LEVEL_2,PRODUCT_LEVEL_3 
	val RefproductList = RefproductLines.map(_.split("\\|")).map(a=>List(a(0).toString,a(1).toString.trim,a(2).toString, a(3).toString, a(4).toString))
	
	//Reading data from file - ACCOUNT_HISTORICAL_DATA_RID
	//Filter - reading last 36 month data
	//Output - ACCOUNT_ID,PRODUCT_IDENTIFIER, SUMMARY_MONTH, AVERAGE_BALANCE_AMT, WORST_BALANCE_AMT, OD_DAYS 
	val AcctHistList = AcctHistLines.map(_.split("\\|")).map(a=>List(a(3).toString,a(5).toString,a(6).toString(), a(7).toString, a(8).toString, a(9).toString))
	.filter{z=> (sdf.parse(z(2)).compareTo(StartDate_36)) >= 0 }.filter{z=> (sdf.parse(z(2)).compareTo(EndDate_12)) <= 0 }.persist
	
	/* Joining  Organisation table and Customer table 
	 * Converting data into key value. <Key,List<value>>
	 */
	
	//Converting List into key Value
	//Output - CUSTOMER_ID,List(CUSTOMER_ID,CUSTOMER_NAME)
	val Orgkeyval=OrgDemoList.map{x=>(x(0),x)}
	
	//Converting List into key Value
	//Output - CUSTOMER_ID,List(CUSTOMER_ID,ACCOUNT_ID,CURRENCY_CODE,MATURITY_DATE)
	val Custkeyval=CustAcctList.map{x=>(x(0),x)}
	
	/* Join Output - (CUSTOMER_ID, List(CUSTOMER_ID,ACCOUNT_ID,CURRENCY_CODE,MATURITY_DATE),List(CUSTOMER_ID,CUSTOMER_NAME))
	 * Joined two list then picked second field(which are itself two lists) then takes fields of our interest
	 * Output - (ACCOUNT_ID, List(ACCOUNT_ID,CURRENCY_CODE,MATURITY_DATE,CUSTOMER_ID,CUSTOMER_NAME))
	 */
	val CustOrgJoin = Custkeyval.join(Orgkeyval).map(x =>x._2).map(x=>(x._1(1),List(x._1(1),x._1(2),x._1(3),x._1(0),x._2(1))))
	
	// Joining result of previous join (customer & organisation) and Account data
	
	//Converting List into key Value
	//Output - ACCOUNT_ID,List(ACCOUNT_ID,ACCOUNT_NAME,ACCOUNT_NUMBER,ACCOUNT_SORT_CODE)
	val AcctKeyval=AcctAttrList.map{x=>(x(0),x)}

	/* Join Output - (ACCOUNT_ID,List(ACCOUNT_ID,CURRENCY_CODE,MATURITY_DATE,CUSTOMER_ID,CUSTOMER_NAME),List(ACCOUNT_ID,ACCOUNT_NAME,ACCOUNT_NUMBER,ACCOUNT_SORT_CODE))
	 * Joined two list then picked second field(which are itself two lists) then takes fields of our interest 
	 * Output - (ACCOUNT_ID, List(ACCOUNT_ID,ACCOUNT_NAME,CURRENCY_CODE,MATURITY_DATE,ACCOUNT_NUMBER,ACCOUNT_SORT_CODE,CUSTOMER_ID,CUSTOMER_NAME))
	 */
	
	val CustOrgAcctJoin= CustOrgJoin.join(AcctKeyval).map(x => x._2).map(x=>(x._1(0),List(x._1(0),x._2(1),x._1(1),x._1(2),x._2(2),x._2(3),x._1(3),x._1(4))))
	
	
	// Calculating MontlyAverage 
	//Output - ACCOUNT_ID|PRODUCT_IDENTIFIER, List(<Number of record>|SUMMARY_MONTH|SUMMARY_MONTH In milliseconds|AVERAGE_BALANCE_AMT|WORST_BALANCE_AMT) 	
	val MonthlyLines36=AcctHistList.map{x=>
										var c = Calendar.getInstance()
										c.setTime(sdf.parse(x(2)))
										var time = c.getTimeInMillis()
										(x(0)+"|"+x(1),List(x(2)+"|"+time+"|"+x(3)+"|"+x(4)))
										}.groupByKey.map(x=>(x._1,List((x._2.flatten.toString.substring(5).substring(0,x._2.flatten.toString.length-6)))))
										.map(x=> (x._1, List(x._2.toString.split(",").length+"|"+x._2(0).replace(", ", "|"))))
										.persist
										//.partitionBy(partition)

	//Reading data from file - ACCOUNT_HISTORICAL_DATA_RID
	//Filter - reading last 12 month data
	//Output - ACCOUNT_ID|PRODUCT_IDENTIFIER,WORST_BALANCE_AMT
	val maxUsed = AcctHistList.filter{z=> (sdf.parse(z(2)).compareTo(StartDate_12)) >= 0 }
							.filter{z=> (sdf.parse(z(2)).compareTo(EndDate_12)) <= 0 }
							.map(a=> (a(0)+"|"+a(1), a(4).toFloat)).reduceByKey{(a,b)=> math.min(a,b)}
							.persist
							//.partitionBy(partition)
	
	//Reading data from file - ACCOUNT_HISTORICAL_DATA_RID
	//Filter - reading last 12 month data
	//Output - ACCOUNT_ID|PRODUCT_IDENTIFIER,avgODdays
	val avgODDays = AcctHistList.filter{z=> (sdf.parse(z(2)).compareTo(StartDate_12)) >= 0 }
								.filter{z=> (sdf.parse(z(2)).compareTo(EndDate_12)) <= 0 }
								.map(a=> (a(0)+"|"+a(1), a(5)))
	     						.mapValues(x=> (x.toInt, 1.0)).reduceByKey((x,y) => (x._1+y._1 , x._2+y._2))
	     						.map(x=> (x._1,(x._2._1/x._2._2).round))
	     						.persist
    							//.partitionBy(partition)
   
	AcctHistList.unpersist()	    					
	//Reading data from DAILY_ACCOUNT_BALANCE_RID    								
	//odDays - OD Days (calculated on last 30 days)
	//Output - ACCOUNT_ID|PRODUCT_IDENTIFIER,odDays
	val odDays=DailyAcctList.filter{z=> (sdf.parse(z(2)).compareTo(dateBefore30Days)) >= 0 }
	     					.filter{z=> (sdf.parse(z(2)).compareTo(ProcDate)) < 0 }
	     					.map{x=>(x(0)+"|"+x(1), if ( x(3).toFloat < 0) 1 else 0 ) }.reduceByKey{(a,b)=> a+b}
	        							
	//Grouping Facilities
	//Output - ACCOUNT_ID|PRODUCT_IDENTIFIER,List(MAXUSED,ODDays,AvgODDays)   								
	val FacilitiesUsageStats= odDays.fullOuterJoin(maxUsed.join(avgODDays))
	     							.map{case(x,y)=> (x, (y._1 match { case Some(j) => j case None => (0)} , y._2 match { case Some(i) => i case None => (0,0)}))}
	     							.map(x=> (x._1, List(x._2._2._1,x._2._1,x._2._2._2))).persist
	
	avgODDays.unpersist()
	maxUsed.unpersist()
	
	//CalcuatedOnDate field dailystats
	//Reading data from DAILY_ACCOUNT_BALANCE_RID(Only PropDate data is required)							
	//Input - ACCOUNT_ID,PRODUCT_IDENTIFIER,SUMMARY_DATE,BALANCE_AMT,LIMIT_AMT,PRODUCT_RATE
	//Output - ACCOUNT_ID|PRODUCT_IDENTIFIER,List(BALANCE_AMT,LIMIT_AMT,PRODUCT_RATE,USAGE(BALANCE/LIMIT))
	val calculatedOnDate = Calendar.getInstance().getTimeInMillis();
	
	val DailyStats_DS=DailyAcctList.filter{z=> (sdf.parse(z(2)).compareTo(ProcDate)) == 0 }
									.filter{z=> (z(6)).compareTo("D") == 0 }
									.map{x=>(x(0)+"|"+x(1),List(x(3),x(4),x(5), 0 ))}
	
	val DailyStats_MS=DailyAcctList.filter{z=> (sdf.parse(z(2)).compareTo(EndDate_12)) == 0 }
									.filter{z=> (z(6)).compareTo("M") == 0 }
									.map{x=>(x(0)+"|"+x(1),List(x(3),x(4),x(5), 0 ))}
									
	val DailyStats = DailyStats_DS.union(DailyStats_MS)    // need code improvement at this point. Here two RDD are reading data which is killing performace 
	
	//DailyStats.foreach(println)
	
	//Joining DailyStats and Facilities Usage
	//Output - (PRODUCT_IDENTIFIER, List(ACCOUNT_ID,PRODUCT_IDENTIFIER,BALANCE_AMT,LIMIT_AMT,PRODUCT_RATE,USAGE,MAXUSED,ODDays,AvgODDays,ProcDateTimestamp,calculatedOnDate)
	val DailyAccount = DailyStats.leftOuterJoin(FacilitiesUsageStats)
								.map{case(x,y)=> (x, (y._1, y._2 match { case Some(i) => i case None => List(0,0,0)}))}
								.map(x => (x._1+"|"+x._2._1(0)+"|"+x._2._1(1)+"|"+x._2._1(2)+"|"+x._2._1(3)+"|"+x._2._2(0)+"|"+x._2._2(1)+"|"+x._2._2(2)))
								.map(_.split("\\|")).map(a=>List(a(0),a(1),a(2),a(3),a(4),a(5),a(6),a(7),a(8),ProcDateTimestamp,calculatedOnDate))
								.map{x=>(x(1).toString,x)}
								//.partitionBy(partition)
	FacilitiesUsageStats.unpersist()							
	
	//Converting List into key Value
	//Output - PRODUCT_IDENTIFIER,List(PRODUCT_IDENTIFIER,PRODUCT_NAME,PRODUCT_LEVEL_1,PRODUCT_LEVEL_2,PRODUCT_LEVEL_3)
	val Refprodkeyval=RefproductList.map{x=>(x(0),x)}
	
	
	//Joining DailyAccount and Refprodkeyval
	//Output - ACCOUNT_ID,BALANCE_AMT,LIMIT_AMT,PRODUCT_RATE,USAGE,MAXUSED,ODDays,AvgODDays,ProcDateTimestamp,calculatedOnDate,PRODUCT_IDENTIFIER,PRODUCT_NAME,PRODUCT_LEVEL_1,PRODUCT_LEVEL_2,PRODUCT_LEVEL_3
	val DailyAccountProduct = DailyAccount.join(Refprodkeyval).map(x =>x._2)
	.map(x=>(x._1(0).toString,List(x._1(2),x._1(3),x._1(4),x._1(5),x._1(6),x._1(7),x._1(8),x._1(9),x._1(10),x._1(1),x._2(1),x._2(2),x._2(3),x._2(4))))
	
		
	/** Output from below statement <Key, List(Value)> 
	key - ACCOUNT_ID|PRODUCT_IDENTIFIER
	Value - ACCOUNT_ID,PRODUCT_IDENTIFIER,ACCOUNT_NAME,CURRENCY_CODE,MATURITY_DATE,ACCOUNT_NUMBER,ACCOUNT_SORT_CODE,CUSTOMER_ID,CUSTOMER_NAME,BALANCE_AMT,LIMIT_AMT,
	PRODUCT_RATE,USAGE,MAXUSED,ODDays,AvgODDays,ProcDateTimestamp,calculatedOnDate,PRODUCT_IDENTIFIER,PRODUCT_NAME,PRODUCT_LEVEL_1,PRODUCT_LEVEL_2,PRODUCT_LEVEL_3
	Value Separator - "|"
	**/

	val account= CustOrgAcctJoin.join(DailyAccountProduct).map(x =>x._2)
	.map(x => (x._1(0)+"|"+x._2(9), List(x._1(0)+"|"+x._2(9)+"|"+RemoveNull(x._1(1))+"|"+x._1(2)+"|"+RemoveNull(x._1(3))+"|"+RemoveNull(x._1(4))+"|"+x._1(5)+"|"+x._1(6)+"|"+x._1(7)+"|"+
	 x._2(0)+"|"+RemoveNull(x._2(1).toString)+"|"+RemoveNull(x._2(2).toString)+"|"+x._2(3)+"|"+x._2(4)+"|"+x._2(5)+"|"+x._2(6)+"|"+x._2(7)+"|"+x._2(8)+"|"+x._2(9)+"|"+x._2(10)+"|"+x._2(11)+"|"+x._2(12)+"|"+x._2(13))))
	//.partitionBy(partition)
	
	/** Output from below statement <Key,List(Values)> 
	key - ACCOUNT_ID|PRODUCT_IDENTIFIER
	Value - <Number of Monthly record>,MONTH<YYYY-MM>,TIMESTAMP,AvgBalance,WorstBalance
	Value Separator - "|"
	**/  
	
	/** Output from below statement - Pipe Separated string 
	value - Join of account RDD and MonthlyLines36 RDD. Value of order refer above comments
	Value Separator - "|"
	**/	 
		
	val Aggregate= account.leftOuterJoin(MonthlyLines36)
						.map{case(x,y)=> (x, (y._1, y._2 match { case Some(i) => i case None => List(0)}))}
						.map(x=> x._2).map(x=> x._1(0)+"|"+x._2(0)).persist()

	MonthlyLines36.unpersist()
	val MongoInsert = Aggregate.map{line =>
									var token = line.toString.split("\\|")
									var ACCOUNT_ID = token(0)
									var ACCOUNT_NAME = token(2)
									var CURRENCY_CODE = token(3)
									var MATURITY_DATE = token(4)
									var ACCOUNT_NUMBER = token(5)
									var ACCOUNT_SORT_CODE = token(6).toInt
									var CUSTOMER_ID = token(7)
									var CUSTOMER_NAME = token(8)
									var BALANCE_AMT = token(9)
									var LIMIT_AMT = StringMultiply1000(token(10).toString())
									var PRODUCT_RATE = StringMultiply1000(token(11).toString())
									//var USAGE = token(12).toString()
									var MAXUSED = token(13)
									var ODDays = token(14)
									var AvgODDays = token(15)
									var ProcDateTimestamp = token(16)
									var calculatedOnDate = token(17)
									var PRODUCT_IDENTIFIER = token(18)
									var PRODUCT_NAME = token(19)
									var PRODUCT_LEVEL_1 = token(20)
									var PRODUCT_LEVEL_2 = token(21)
									var PRODUCT_LEVEL_3 = token(22)
									var monthCount = token(23)
									
									var base = 24
									var documentDetail = new ArrayList[BasicDBObject](36)
									
									
									for (i <- 1 to monthCount.toInt){
									    var document = new BasicDBObject();
										var timeStamp  = token(base + 1).toString()
										var avgBalance = token(base + 2).toString()
										var worstBalance = token(base + 3).toString()
										base = base + 4
																	
										document.append("date",timeStamp.toDouble);
										document.append("avgBalance", (avgBalance.toDouble.*(1000)).toInt);
										document.append("worstBalance", (worstBalance.toDouble.*(1000)).toInt);
										
										documentDetail.add(document)
									}
									
														
									var documentProdcut = BasicDBObjectBuilder.start()
															.add("productName", PRODUCT_NAME)
															.add("productID", PRODUCT_IDENTIFIER.toInt)
															.add("productLevel1", PRODUCT_LEVEL_1)
															.add("productLevel2", PRODUCT_LEVEL_2)
															.add("productLevel3", PRODUCT_LEVEL_3).get();
								
									var documentFacilities = BasicDBObjectBuilder.start()
															.add("date", ProcDateTimestamp.toDouble)
															.add("maxUsed", MAXUSED.toDouble)
															.add("avgDays", AvgODDays.toInt)
															.add("odDays", ODDays.toInt)
															.add("calculatedOnDate", calculatedOnDate.toDouble).get();
							
									var documentCustomer = BasicDBObjectBuilder.start()
															.add("customerID", CUSTOMER_ID.toInt)
															.add("customerName", CUSTOMER_NAME).get();
									
									var documentdaily = BasicDBObjectBuilder.start()
															.add("date", ProcDateTimestamp.toDouble)
															.add("balance", (BALANCE_AMT.toDouble.*(1000)).toInt)
															.get();
									
									var documentAccount = BasicDBObjectBuilder.start()
															.add("accountID", ACCOUNT_ID.toDouble)
															.add("sortCode",ACCOUNT_SORT_CODE)
															.add("accountNumber",ACCOUNT_NUMBER)
															.add("accountName",ACCOUNT_NAME)
															.add("customer",documentCustomer)
															.add("currency",CURRENCY_CODE)
															.add("balance", (BALANCE_AMT.toDouble.*(1000)).toInt)
															.add("limit",LIMIT_AMT)
															.add("rate",PRODUCT_RATE)
															.add("maturity",MATURITY_DATE)
															.add("product",documentProdcut)
															.add("facilitiesUsageStats",documentFacilities)
															.add("dailystats",documentdaily)
															.add("monthlyAverages",documentDetail).get();
									
									var updateQuery = BasicDBObjectBuilder.start()
													.add("accountID", ACCOUNT_ID.toDouble)
													.add("product.productID", PRODUCT_IDENTIFIER.toInt).get();
									
									val temp= List(updateQuery, documentAccount)
									temp															
	}
	
	
	/* Adding pipe in end of aggregate if it having data less than 36 months 
	 * It making every line with similar structure so that it can be loaded in hive
	 */
	
	val AggregateH = Aggregate.map{line =>
	  								var tokenCount = line.toString.split("\\|").length
	  								if (tokenCount < 167) 
	  								{
	  									var pad = new StringBuilder()
	  									for (i <- tokenCount to 167){
	  										pad.append("|")
	  									}
	  									line+pad
	  								}
	  								else
	  									line.toString() 
	}
						
	AggregateH.saveAsTextFile(RiAggregate)
	
	//AggregateH.foreach(println)
	
	/* MongoInsert.foreachPartition{
	  msgIterator => {

		//	System.setProperty("javax.security.auth.useSubjectCredsOnly","false")
		//	System.setProperty("sun.security.krb5.debug","true")
		//	System.setProperty("java.security.krb5.realm","INTRANET.BARCAPINT.COM");
		//	System.setProperty("java.security.krb5.kdc","intranet.barcapint.com");
		//  var url = new MongoClientURI(uri)
		//  var mongo = new MongoClient(url)  

	    var mongo = new MongoClient(IP_Address,Port)
	    var db = mongo.getDB(DBName)
	    var col = db.getCollection(Collection)
	    msgIterator.foreach{y =>
	    	addMongo(y(0),y(1), col)  
	    }
		mongo.close()
	  }	
	} */
	
	Aggregate.unpersist() 
	sc.stop  
  }
  
  	def addMongo(up:DBObject, st:DBObject, col:DBCollection)
  	{
	    col.update(up, st, true, false)
    }
  	
  	def RemoveNull(st:String) : String =
  	{
  	    var tmp:String=""
	    if (st.compareTo("null") != 0){
	      tmp=st.trim()
	     }
	    return  tmp
    }
  	def StringMultiply1000(st:String) : String =
  	{
  	    var tmp:String=""
	    if ((st.trim()).compareTo("") != 0){
	      tmp = (((st.trim()).toFloat*(1000)).toInt).toString
	     }
	    return  tmp
    }
}