package com.barclays.rid.gca.filter;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import cascading.flow.FlowProcess;
import cascading.operation.BaseOperation;
import cascading.operation.Filter;
import cascading.operation.FilterCall;
import cascading.tuple.TupleEntry;

public class DateFilter extends BaseOperation implements Filter {

	/**
	 * 
	 */
	
	private String oper;
	private  String strDate1;
	private  String strDate2;

	public DateFilter(String oper)
	{
		super(2);  // This will make sure that there are two arguments passed on the pipe
		System.out.println("in constructor1"+oper);
		this.oper = oper;

	}

	public DateFilter(String oper, String strDate1){

		super(1);  // This will make sure that there is one argument passed on the pipe		
		System.out.println("in constructor2"+oper+"----"+strDate1);
		this.oper = oper;
		this.strDate1 = strDate1;
	} 

	public DateFilter(String oper, String strDate1, String strDate2){
		super(1);  // This will make sure that there is one argument passed on the pipe
		System.out.println("in constructor3"+oper);
		this.oper = oper;
		this.strDate1 = strDate1;
		this.strDate2 = strDate2;
	} 

	public boolean isRemove( FlowProcess flowProcess, FilterCall call )
	{
		
		// get the arguments TupleEntry
		TupleEntry arguments = call.getArguments();
		System.out.println("in constructor2"+oper+"----"+strDate1);

		// initialize the return result
		boolean isRemove = false;

		try{
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			int NumOfArgs = arguments.size();
			Date date1 = new Date();
			Date date2 = new Date();
			Date date3 = new Date();

			if(NumOfArgs==2) {
				date1 = sdf.parse(arguments.getString(0));
				date2 = sdf.parse(arguments.getString(1));    
			} else if(NumOfArgs==1 && strDate1!=null && strDate2==null)	{
				date1 = sdf.parse(arguments.getString(0));
				date2 = sdf.parse(strDate1);
			} else if(NumOfArgs==1 && strDate1!=null && strDate2!=null)	{
				date1 = sdf.parse(arguments.getString(0));
				date2 = sdf.parse(strDate1);
				date3= sdf.parse(strDate2);
				//	cal3.setTime(date3);
			}

			if(oper.equals("=") && date1.compareTo(date2)==0)
			{
				System.out.println("++++++"+date1+"++++++++"+oper+"++++++++++++"+date2);
				isRemove=true;
				return isRemove;
			}
			else if(oper.equals("<") && date1.compareTo(date2)<0)
			{
				System.out.println("++++++"+date1+"++++++++"+oper+"++++++++++++"+date2);
				isRemove=true;
				return isRemove;
			}
			else if(oper.equals("<=") && date1.compareTo(date2)<=0)
			{
				System.out.println("++++++"+date1+"++++++++"+oper+"++++++++++++"+date2);
				isRemove=true;
				return isRemove;
			}
			else if(oper.equals(">") && date1.compareTo(date2)>0)
			{
				System.out.println("++++++"+date1+"++++++++"+oper+"++++++++++++"+date2);
				isRemove=true;
				return isRemove;
			}
			else if(oper.equals(">=") && date1.compareTo(date2)>=0)
			{
				System.out.println("++++++"+date1+"++++++++"+oper+"++++++++++++"+date2);
				isRemove=true;
				return isRemove;
			}
			else if(oper.equals("<>") && date1.compareTo(date2)!=0)
			{
				System.out.println("++++++"+date1+"++++++++"+oper+"++++++++++++"+date2);
				isRemove=true;
				return isRemove;
			}


		}catch(ParseException ex){
			ex.printStackTrace(); 
		}
		return isRemove;
	}

}
