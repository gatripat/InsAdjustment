package com.barclays.rid.gca.utils;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

public class Utils {
	public boolean checkNull(String param){
		if(param!= null && !param.isEmpty())
		{
		return true;
		}
		return false;
	}
	
	public HashMap<String, String> paramParser(String file) {
		 HashMap<String, String> paramMap;
		paramMap = new HashMap<String, String>();
		String line = "";

		try {
			FileReader fileReader = new FileReader(file);

			BufferedReader bufferedReader = new BufferedReader(fileReader);

			while ((line = bufferedReader.readLine()) != null) {
				if (!(line.length() == 0 || line.startsWith("#"))) {
					paramMap.put(line.split("=", -1)[0].trim(), line.split("=", -1)[1].trim());
				}
			}

			bufferedReader.close();
		} catch (FileNotFoundException ex) {
			System.out.println("Unable to open file '" + file + "'");
		} catch (IOException ex) {
			System.out.println("Error reading file '" + file + "'");
			ex.printStackTrace();
		}
		return paramMap;

	}


}
