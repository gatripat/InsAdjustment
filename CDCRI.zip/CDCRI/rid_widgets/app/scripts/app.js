'use strict';

/**
 * @ngdoc overview
 * @name relationshipInsightDocApp
 * @description
 * # relationshipInsightDocApp
 *
 * Main module of the application.
 */
angular
	.module('relationshipInsightDocApp', [
    'ngAnimate',
    'ngCookies',
    'ngResource',
    'ngRoute',
    'ngSanitize',
    'ngTouch'
  ])
	.config(function ($routeProvider) {
		$routeProvider
			.when('/start', {
				templateUrl: 'views/main.html',
				controller: 'MainCtrl',
				controllerAs: 'main'
			})
			.when('/library', {
				templateUrl: 'views/examples.html',
				controller: 'ExamplesCtrl',
				controllerAs: 'examples'
			})
			.when('/developer', {
				templateUrl: 'views/developer.html',
				controller: 'DeveloperCtrl',
				controllerAs: 'developer'
			})
			.when('/demo', {
				templateUrl: 'views/demo.html',
				controller: 'DemoCtrl',
				controllerAs: 'demo'
			})
			.when('/dataAPIS', {
				templateUrl: 'views/data-apis.html',
				controller: 'DataCtrl',
				controllerAs: 'demo'
			})
			.otherwise({
				redirectTo: '/demo'
			});
	});