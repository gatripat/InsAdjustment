var examplePieChart = examplePieChart || {};

examplePieChart.barclaysColors = [
        'rgba(0,56,94, 1)',
        'rgba(0,125,184, 1)',
        'rgba(45,150,68, 1)',
        'rgba(255,190,16,1)',
        'rgba(255,36,0, 1)',
        //'rgba(236,100,0, 1)',
        'rgba(159,0,57, 1)',
        'rgba(177,161,148, 1)',
        'rgba(204,51,51,1)',
        'rgba(114,163,9, 1)',
        'rgba(177,161,148, 0.5)',
        'rgba(0,56,94, 0.5)',
        'rgba(0,125,184, 0.5)',
        'rgba(45,150,68, 0.5)',
        'rgba(255,190,16,0.5)',
        'rgba(236,100,0, 0.5)',
        'rgba(159,0,57, 0.5)',
        'rgba(220,99,10,0.5)',
        'rgba(114,163,9, 0.5)',
        'rgba(204,51,51, 0.5)',
        'rgba(0,174,239, 1)'
    ];

/*create the account listener to listen to when the dropdown is changed*/
examplePieChart.accountListener = function (widgetOpts) {
	$('#account-selector-' + widgetOpts.id).unbind();
	$('#account-selector-' + widgetOpts.id).change(function () {
		console.log("channel toggle change detected");
		console.log('text: ' + $('#account-selector-' + widgetOpts.id + ' option:selected').text() + ', val: ' + $("#account-selector-" + widgetOpts.id).val());
		examplePieChart.initChart(widgetOpts);
	});
};

examplePieChart.durationListener  = function (widgetOpts) {
	$('#duration-selector-' + widgetOpts.id).unbind();
	$('#duration-selector-' + widgetOpts.id).change(function () {
		console.log("channel toggle change detected");
		console.log('text: ' + $('#duration-selector-' + widgetOpts.id + ' option:selected').text() + ', val: ' + $("#duration-selector-" + widgetOpts.id).val());
		examplePieChart.initChart(widgetOpts);
	});
};





examplePieChart.initChart = function (widgetOpts) {
	
	d3.select("#" + widgetOpts.id)
	.append("svg:svg")

	/*selector for creating accounts id's*/
	var createSelector = function () {
		var select = document.createElement("select");
		select.setAttribute("id", "account-selector-" + widgetOpts.id);
		var eElement = document.getElementById(widgetOpts.id);
		eElement.insertBefore(select, eElement.firstChild);
		
		
		for (var i = 0; i < examplePieChart.custArray.length; i++) {
			var opt = examplePieChart.custArray[i].accountID;
			var el = document.createElement("option");
			el.textContent = 'A/N: ' + examplePieChart.custArray[i].accountNumber;
			el.value = opt;
			select.appendChild(el);
		}
		/*once the dropdown is created initiate the account listener to detect when this changes*/
		examplePieChart.accountListener(widgetOpts);
	}

	/*append div bottom of pie chart*/
	var createDiv = function () {
		
		var monthArray = examplePieChart.chartData
		monthArray = monthArray[0].TARRIF;
		
		var monthArrayTarrif = examplePieChart.chartData
		monthArrayTarrif = monthArrayTarrif[0].TARRIF_OK;
		$("#" + widgetOpts.id).append( "<div class='bottomDiv'>A breakdown of charges from the past 12 months.</div>" );
		$("#" + widgetOpts.id).append( "<div class='bottomDivNew'>" + (monthArrayTarrif === "Green" ? "<div style='display: inline-block; height: 7px; width: 15px; border-left: solid 3px green; border-bottom: solid 3px green; transform: rotate(-45deg);'></div>": "")  + "<b> Tariff:</b>"+ " " + monthArray + "</div>");

	}
	
	
	/*selector for creating duration*/	
	var createSelectorNew = function () {
		var select = document.createElement("select");
		select.setAttribute("id", "duration-selector-" + widgetOpts.id);
		var eElement = document.getElementById(widgetOpts.id);
		eElement.insertBefore(select, eElement.firstChild);
		
		var monthArray = examplePieChart.chartData
		monthArray = monthArray[0].values;
		
		for (var i = 0; i < monthArray.length; i++) {
			var opt = monthArray[i].DURATION;
			var el = document.createElement("option");
			el.textContent = opt;
			el.value = opt;
			select.appendChild(el);
		}
		
		/*once the dropdown is created initiate the account listener to detect when this changes*/
		examplePieChart.durationListener(widgetOpts);
	}
	
	
	var loadGraph = function () {

		//set the basic styling
		$('#' + widgetOpts.id).css("height", widgetOpts.chartHeight ? widgetOpts.chartHeight : "300px");
		$('#' + widgetOpts.id).css("width", widgetOpts.chartWidth ? widgetOpts.chartWidth : "auto");
		$('#' + widgetOpts.id).css("margin-bottom", "10px");

		var rawData = examplePieChart.chartData
		var durationID = $("#duration-selector-" + widgetOpts.id).val()
		rawData = rawData[0].values.filter(function (d) {
			return d.DURATION === durationID 
			});
		
		var data = rawData[0].values
		
		var setStyling = function () {
			setTimeout(function () {
				if (widgetOpts.textColor) {
					$('#' + widgetOpts.id + ' .nvd3 text').css("fill", widgetOpts.textColor);
				}
				if (widgetOpts.xlabelColor) {
					$('#' + widgetOpts.id + ' .nv-x .nvd3 text').css("fill", widgetOpts.xlabelColor);
				}
				if (widgetOpts.ylabelColor) {
					$('#' + widgetOpts.id + ' .nv-y .nvd3 text').css("fill", widgetOpts.ylabelColor);
				}
				$('#' + widgetOpts.id + ' .nv-pieLabels text').css("fill", widgetOpts.pieLabelColor ?  widgetOpts.pieLabelColor : "white").css("font-size", "14px");
				if (widgetOpts.fontSize) {
					$('#' + widgetOpts.id + ' .nvd3 text').css("font-size", widgetOpts.fontSize);
				}
				if (widgetOpts.fontFamily) {
					$('#' + widgetOpts.id + ' .nvd3 text').css("font-family", widgetOpts.fontFamily);
				}
			}, 200);
		};
		
		var chartTitle =  rawData[0].Total; 
		nv.addGraph(function () {
			var chart = nv.models.pieChart()
			.margin({
					bottom: 30
				})
				.x(function (d) {
					return d.label
				})
				.y(function (d) {
					return d.value
				})
				.color(widgetOpts.chartColors ? widgetOpts.chartColors : exampleBarChart.barclaysColors)
				.showLabels(true)
			.labelType("value")
				.labelThreshold(.05)
				.donut(true)
				.donutRatio(0.35) 
				.title("£"+ " " + chartTitle).titleOffset(0)
//				.legendPosition("right")
				;

			d3.select('#' + widgetOpts.id + ' svg')
				.datum(data)
				.transition().duration(1200)
				.call(chart);

			nv.utils.windowResize(function () {
				chart.update()
				setStyling();
			});

			return chart;
		});
		setStyling();

	};
	
	

	var processCustData = function (custData) {
		if (widgetOpts.dataLineage) {
			var a = widgetOpts.dataLineage.split("|");
			a.forEach(function (d) {
				custData = custData[d];
			});
		}
		examplePieChart.custArray = [];
		custData.products.forEach(function (d) {
			if (d.productLevel1 === "DEPOSITS") {
				examplePieChart.custArray = examplePieChart.custArray.concat(d.accounts);
			}
		});
		examplePieChart.custArray.sort(function (a, b) {
			var x = a.primary;
			var y = b.primary;
			return ((x > y) ? -1 : ((x < y) ? 1 : 0));
		});
		console.log(examplePieChart.custArray)
		createSelector();
	};

	var processMonthlyData = function (data) {
		var noData = [
			{
				"accountID": 34567,
				"monthlyAverage": [
					{
						"key": "2016",
						"values": [[]]
												}]
										}]
		if (widgetOpts.dataLineage) {
			var a = widgetOpts.dataLineage.split("|");
			a.forEach(function (d) {
				data = data[d];
			});
		}
		examplePieChart.chartData = !data || data.length === 0 ? noData : data;
		
		if ($("#duration-selector-" + widgetOpts.id).length === 0){
			createSelectorNew();
			createDiv();
		}
		loadGraph();

	};

	var getDataURL = function () {
		if (widgetOpts.api) {
			/*monthly stats data*/
			var getMonthlyData = function () {

				
				var accountID = $("#account-selector-" + widgetOpts.id).val()
				console.log('acc ID: ' + accountID);

				//PROD CODE
				/*var URLconstruct = widgetOpts.api + '/accounts/monthlyStats/' + accountID;*/
				var URLconstruct = widgetOpts.api + '/pieChart.json';

				$.get(URLconstruct, function (data) {

				}).done(function (data) {
					try {
						data = $.parseJSON(data);
					} catch (err) {}
					console.log(data);
					processMonthlyData(data)
				}).fail(function () {
					console.log('fail');
					processMonthlyData([])
				});

			};
			/*Get customer data*/
			var getCustomerData = function () {
				var custNo = $('#' + widgetOpts.id).data("cust");
				$.get(widgetOpts.api + '/customer/' + custNo, function (customers) {
					try {
						customers = $.parseJSON(customers);
					} catch (err) {}
					processCustData(customers);
					getMonthlyData();
				});

			};

			if (!examplePieChart.custArray || $("#account-selector-" + widgetOpts.id).length === 0) {
				/*Only need to get the customer data once - don't need to get it each time the dropdown changes */
				getCustomerData();
			} else {
				getMonthlyData();
			}
		}
	};

	var getDataFun = function () {

		/*use functions written by the end application*/
		if (!examplePieChart.custArray || $("#account-selector-" + widgetOpts.id).length === 0) {
			var customers = widgets[widgetOpts.api + 'cust']();
			processCustData(customers);
			var accountID = $("#account-selector-" + widgetOpts.id).val()
			examplePieChart.chartData = widgets[widgetOpts.api + 'monthly'](accountID);
		} else {
			var accountID = $("#account-selector-" + widgetOpts.id).val()
			console.log('acc ID: ' + accountID);
			examplePieChart.chartData = widgets[widgetOpts.api + 'monthly'](accountID);
		}
		processMonthlyData(examplePieChart.chartData);
	};

	//URL to be set to true or false
	if (URL) {
		getDataURL();
	} else {
		getDataFun();
	}

};