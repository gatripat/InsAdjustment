'use strict';

var overdraftChart = overdraftChart || {};

overdraftChart.barclaysColors = ['rgb(0, 126, 182)', '#B23B65'];

/*create the account listener to listen to when the dropdown is changed*/
overdraftChart.accountListener = function (widgetOpts) {
	$('#account-selector-' + widgetOpts.id).unbind();
	$('#account-selector-' + widgetOpts.id).change(function () {
		console.log("channel toggle change detected");
		console.log('text: ' + $('#account-selector-' + widgetOpts.id + ' option:selected').text() + ', val: ' + $("#account-selector-" + widgetOpts.id).val());
		overdraftChart.initChart(widgetOpts);
	});
};

overdraftChart.initChart = function (widgetOpts) {

	if ($("#usageData-" + widgetOpts.id).length === 0) {
		/*first add the chart container div*/
		d3.select("#" + widgetOpts.id)
			.append("div")
			.style("display", "inline-block")
			.style("width", "60%")
			.style("height", widgetOpts.chartHeight ? widgetOpts.chartHeight : "300px")
			.style("float", "left")
			.append("svg:svg");

		d3.select("#" + widgetOpts.id)
			.append("div")
			.style("display", "inline-block")
			.style("width", "40%")
			.style("height", widgetOpts.chartHeight ? widgetOpts.chartHeight : "300px")
			.style("float", "left")
			.style("border-left", "1px solid lightgrey")
			.attr("id", "usageData-" + widgetOpts.id);
	}



	/*selector for creating accounts*/
	var createSelector = function () {
		var div = document.createElement("div");
		div.setAttribute("style", "display: block; width: 100%; height: 30px;");
		var select = document.createElement("select");
		select.setAttribute("id", "account-selector-" + widgetOpts.id);
		var eElement = document.getElementById(widgetOpts.id);
		div.appendChild(select);
		eElement.insertBefore(div, eElement.firstChild);

		for (var i = 0; i < overdraftChart.custArray.length; i++) {
			var opt = overdraftChart.custArray[i].accountID;
			var el = document.createElement("option");
			el.textContent = 'A/N: ' + overdraftChart.custArray[i].accountNumber + ' S/C: ' + overdraftChart.custArray[i].sortCode;
			el.value = opt;
			select.appendChild(el);
		}
		/*once the dropdown is created initiate the account listener to detect when this changes*/
		overdraftChart.accountListener(widgetOpts);
	}

	var loadUsageData = function (usageData) {


		var data = [{
			val: usageData ? d3.format(",.0f")	(usageData.dailyBalances[0].usage) : "--",
			key: 'Current usage',
			color: "grey"
		}, {
			val: usageData ? d3.format(",.0f")	(usageData.dailyBalances[0].limit) : "--",
			key: 'Overdraft limit',
			color: "#61B073"
		}]

		d3.select("#usageData-" + widgetOpts.id)
			.selectAll("div").remove();
		d3.select("#usageData-" + widgetOpts.id)
			.selectAll("svg").remove()

		d3.select("#usageData-" + widgetOpts.id)
			.selectAll("div")
			.data(data)
			.enter()
			.append("div")
			.attr("id", function (d) {
				return d.line_id;
			})
			.html(function (d) {
				return '<span style="font-size: 20px">' + d.key + '</span><br><span style="color: ' + d.color + '"><span style="font-size: 16px">£</span>' + d.val + '</span>';
			})
			.style("width", "50%")
			.style("font-size", "24px")
			.style("padding", "10px")
			.style("display", "inline-block")
			.style("float", "left")
			.style("text-align", "center");

		var svg = d3.select("#usageData-" + widgetOpts.id).append("div").style("height", "230px").style("width", "100%").append("svg:svg").attr("viewBox", "0 0 420 230");

		var width = $("#usageData-" + widgetOpts.id).width();
		var jsonCircles = [
			{
				"x_axis": 120,
				"y_axis": 100,
				"radius": 90,
				"color": "#007EB6", //"transparent",
				stroke: "#007EB6",
				strokeWidth: "9px",
				value: usageData ? d3.format(",.0f")(usageData.usage.avgDaysPerMonth) + " days/month" : "--" + " days/month",
				label: "Average days in overdraft",
				label_x: 20,
				labelfontSize: "18px",
				labelFill: "white",//"green"
				valFill: "white"
			},
			{
				"x_axis": 330,
				"y_axis": 40,
				"radius": 30,
				"color": "rgb(0, 57, 92)",
				"value": usageData ? d3.format(",.0f")(usageData.dailyBalances[0].usage/usageData.dailyBalances[0].limit*100) + "%" : "--%",
				"label": "Max used",
				"val2": usageData ? d3.format(",.0f")	(usageData.usage.maxUsedOver12Months) : "--",
				valFill: "white"
			},
			{
				"x_axis": 330,
				"y_axis": 150,
				"radius": 30,
				"color": "rgb(0, 57, 92)",
				"value": usageData ? d3.format(",.0f")	(usageData.usage.odDaysInMonth) : "--",
				"label": "Days in overdraft this month",
				label_x: 60,
				valFill: "white"
			}];

		var nodes = svg.append("g")
			.selectAll("circle")
			.data(jsonCircles)
			.enter()
			// Add one g element for each data node here.
			.append("g")
			.attr("transform", function (d, i) {
				// Set d.x and d.y here so that other elements can use it. d is 
				// expected to be an object here.
				return "translate(" + d.x_axis + "," + d.y_axis + ")";
			});

		var circles = nodes.append("circle");

		var circleAttributes = circles
			.attr("r", function (d) {
				return d.radius;
			})
			.style("fill", function (d) {
				return d.color;
			})
			.style("stroke", function (d) {
				return d.stroke || "transparent";
			})
			.style("stroke-width", function (d) {
				return d.strokeWidth || "0px";
			});

		nodes.append("text")
			.attr("text-anchor", "middle")
			.attr("font-size", function (d, i) {
				return d.labelfontSize;
			})
			.attr("fill", function (d, i) {
				return d.valFill;
			})
			.text(function (d) {
				return d.value;
			});

		nodes.append("text")
			.attr("dy", function (d, i) {
				return d.label_x ? d.label_x : d.y_axis + 10;
			})
			.attr("text-anchor", "middle")
			.attr("fill", function (d, i) {
				return d.labelFill;
			})
			.text(function (d) {
				return d.label;
			})
		
		nodes.append("text")
			.attr("dy", function (d, i) {
				return d.label_x ? d.label_x + 30 : d.y_axis + 30;
			})
			.attr("text-anchor", "middle")
			.text(function (d) {
				return d.val2 ?  ("£" + d.val2) : "";
			})
		.attr("font-size", "16px")
			.attr("fill", "red")

	};

	var loadGraph = function () {
		$('#' + widgetOpts.id).css("height", widgetOpts.chartHeight ? widgetOpts.chartHeight : "300px");
		$('#' + widgetOpts.id).css("width", widgetOpts.chartWidth ? widgetOpts.chartWidth : "auto");
		$('#' + widgetOpts.id).css("margin-bottom", "10px");
		$('#' + widgetOpts.id + ' svg').css("width", widgetOpts.chartWidth ? widgetOpts.chartWidth : "100%");

		var data = overdraftChart.chartData;

		data = data[0].monthlyAverage;

		var setStyling = function () {
			setTimeout(function () {
				if (widgetOpts.textColor) {
					$('#' + widgetOpts.id + ' .nvd3 text').css("fill", widgetOpts.textColor);
				}
				if (widgetOpts.xlabelColor) {
					$('#' + widgetOpts.id + ' .nv-x .nvd3 text').css("fill", widgetOpts.xlabelColor);
				}
				if (widgetOpts.ylabelColor) {
					$('#' + widgetOpts.id + ' .nv-y .nvd3 text').css("fill", widgetOpts.ylabelColor);
				}
				if (widgetOpts.fontSize) {
					$('#' + widgetOpts.id + ' .nvd3 text').css("font-size", widgetOpts.fontSize);
				}
				if (widgetOpts.fontFamily) {
					$('#' + widgetOpts.id + ' .nvd3 text').css("font-family", widgetOpts.fontFamily);
				}
			}, 100);
		};

		nv.addGraph(function () {
			var chart = nv.models.lineChart()
				.margin({
					left: 100
				})
				.x(function (d) {
					return d.month;
				})
				//adjusting, 100% is 1.00, not 100 as it is in the data
				.y(function (d) {
					return d.worstBalance;
				})
				.color(widgetOpts.chartColors ? widgetOpts.chartColors : overdraftChart.barclaysColors)
				.interpolate("cardinal")
				.useInteractiveGuideline(true);

			chart.xAxis
				.tickFormat(function (d) {
					return d3.time.format('%b')(new Date(0, d, 1))
				});

			chart.xAxis.tickValues(data[0].values.map(function (d) {
				return d.month;
			}));

			chart.yAxis.tickFormat(function (d) {
				return '£' + d3.format(',.2f')(d)
			});

			chart.legend.dispatch.legendClick = function () {
				setStyling();
			};

			d3.select('#' + widgetOpts.id + ' svg')
				.datum(data)
				.transition().duration(500)
				.call(chart);

			nv.utils.windowResize(function () {
				chart.update();
				setStyling();
			});

			return chart;
		});

		setStyling();
	};


	var processCustData = function (custData) {
		if (widgetOpts.dataLineage) {
			var a = widgetOpts.dataLineage.split("|");
			a.forEach(function (d) {
				custData = custData[d];
			});
		}
		overdraftChart.custArray = [];
		custData.products.forEach(function (d) {
			if (d.productLevel1 === "DEPOSITS") {
				overdraftChart.custArray = overdraftChart.custArray.concat(d.accounts);
			}
		});
		overdraftChart.custArray.sort(function (a, b) {
			var x = a.primary;
			var y = b.primary;
			return ((x > y) ? -1 : ((x < y) ? 1 : 0));
		});
		console.log(overdraftChart.custArray)
		createSelector();
	};

	var processMonthlyData = function (data, usageData) {
		var noData = [
			{
				"accountID": 34567,
				"monthlyAverage": [
					{
						"key": "2016",
						"values": [[]]
												}]
										}]
		if (widgetOpts.dataLineage) {
			var a = widgetOpts.dataLineage.split("|");
			a.forEach(function (d) {
				data = data[d];
				usageData = usageData[d]
			});
		}
		console.log(usageData);
		overdraftChart.chartData = !data || data.length === 0 ? noData : data;
		if ((data || data.length > 0) && usageData) {
			var limit = {
               "key":"Limit",
               "values":[]};
			for (var i = 0; i < 12; i++) {
			limit.values.push({
			  "month":i,
              "worstBalance":usageData.dailyBalances[0].limit});
			}
			
			overdraftChart.chartData[0].monthlyAverage.push(limit);
		}
		
		loadGraph();
		loadUsageData(usageData);

	};

	var getDataURL = function () {
		if (widgetOpts.api) {
			/*monthly stats data*/
			var getMonthlyData = function () {

				var accountID = $("#account-selector-" + widgetOpts.id).val()
				console.log('acc ID: ' + accountID);

				//PROD CODE
//				var URLconstruct = widgetOpts.api + '/accounts/monthlyStats/' + accountID;
				var URLconstruct_monthly = widgetOpts.api + '/accounts/monthlyStats/newMonthlyStats.json';
				var URLconstruct_usage = widgetOpts.api + '/accounts/overdraftUsage/' + accountID;

				
				var monthlyData =  $.ajax({
					url: URLconstruct_monthly,
					type: 'GET',
					datatype: 'text'
				});
				
				var usageData =  $.ajax({
					url: URLconstruct_usage,
					type: 'GET',
					datatype: 'text'
				});
				
				Promise.all([monthlyData, usageData]).then(function (data) {
					try {
						data[0] = $.parseJSON(data[0]);
					} catch (err) {}
					try {
						data[1] = $.parseJSON(data[1]);
					} catch (err) {}
				processMonthlyData(data[0], data[1])
				}).catch(function () {
					console.log('fail');
					processMonthlyData([])
				});

			};
			/*Get customer data*/
			var getCustomerData = function () {
				var custNo = $('#' + widgetOpts.id).data("cust");
				$.get(widgetOpts.api + '/customer/' + custNo, function (customers) {
					try {
						customers = $.parseJSON(customers);
					} catch (err) {}
					processCustData(customers);
					getMonthlyData();
				});

			};

			if (!overdraftChart.custArray || $("#account-selector-" + widgetOpts.id).length === 0) {
				/*Only need to get the customer data once - don't need to get it each time the dropdown changes */
				getCustomerData();
			} else {
				getMonthlyData();
			}
		}
	};

	var getDataFun = function () {

		/*use functions written by the end application*/
		if (!overdraftChart.custArray || $("#account-selector-" + widgetOpts.id).length === 0) {
			var customers = widgets[widgetOpts.api + 'cust']();
			processCustData(customers);
			var accountID = $("#account-selector-" + widgetOpts.id).val()
			overdraftChart.chartData = widgets[widgetOpts.api + 'monthly'](accountID);
		} else {
			var accountID = $("#account-selector-" + widgetOpts.id).val()
			console.log('acc ID: ' + accountID);
			overdraftChart.chartData = widgets[widgetOpts.api + 'monthly'](accountID);
		}
		processMonthlyData(overdraftChart.chartData);
	};



	/*Initiate the get function to get the data depending on wether it will use a URL or dataFunction*/
	if (widgetOpts.URL) {
		getDataURL();
	} else {
		getDataFun();
	}



};