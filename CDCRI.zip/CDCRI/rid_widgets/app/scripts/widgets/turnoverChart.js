'use strict';

var turnoverChart = turnoverChart || {};

turnoverChart.barclaysColors = [
        'rgba(0,56,94, 1)',
        'rgba(0,125,184, 1)',
        'rgba(45,150,68, 1)',
        'rgba(255,190,16,1)',
        'rgba(255,36,0, 1)',
        //'rgba(236,100,0, 1)',
        'rgba(159,0,57, 1)',
        'rgba(177,161,148, 1)',
        'rgba(204,51,51,1)',
        'rgba(114,163,9, 1)',
        'rgba(177,161,148, 0.5)',
        'rgba(0,56,94, 0.5)',
        'rgba(0,125,184, 0.5)',
        'rgba(45,150,68, 0.5)',
        'rgba(255,190,16,0.5)',
        'rgba(236,100,0, 0.5)',
        'rgba(159,0,57, 0.5)',
        'rgba(220,99,10,0.5)',
        'rgba(114,163,9, 0.5)',
        'rgba(204,51,51, 0.5)',
        'rgba(0,174,239, 1)'
    ];


turnoverChart.initChart = function (widgetOpts) {

	d3.select("#" + widgetOpts.id).selectAll("svg").remove();
	d3.select("#" + widgetOpts.id).selectAll("div").remove();
	
	
		/*first add the chart container div*/
		d3.select("#" + widgetOpts.id)
			.append("div")
			.style("display", "inline-block")
			.style("width", "85%")
			.style("height", widgetOpts.chartHeight ? widgetOpts.chartHeight : "300px")
			.style("float", "left")
			.append("svg:svg");

		d3.select("#" + widgetOpts.id)
			.append("div")
			.style("display", "inline-block")
			.style("width", "15%")
			.style("height", widgetOpts.chartHeight ? widgetOpts.chartHeight : "300px")
			.style("float", "left")
			.attr("id", "arrow-" + widgetOpts.id);
	

	var loadDivs = function () {
		
		d3.select("#arrow-" + widgetOpts.id)
			.selectAll("svg").remove()

		var tip = d3.select("body").append("div")
			.attr("class", "tooltip")
			.style("background", "#FFF")
			.style("border", "solid 2px #007DB8")
			.style("border-radius", "5px")
			.style("opacity", 0);

		var svg = d3.select("#arrow-" + widgetOpts.id).append("svg:svg").attr("viewBox", "0 0 200 200").on("mouseover", function (d) {
				var tipFormat = function (d) {
					return d3.time.format(" %H:%M %d-%b-%y")(d)
				};
				tip.transition()
					.duration(200)
					.style("opacity", .9);
				tip.html('<div style="padding: 10px; color: ' + (widgetOpts.textColor ? widgetOpts.textColor : "#007DB8") + '"><li>Based on monthly average run rate</li><li>Year to date compared to month last year</li></div>')
					.style("left", (d3.event.pageX) + "px")
					.style("top", (d3.event.pageY) + "px");
			})
			.on("mouseout", function (d) {
				tip.transition()
					.duration(500)
					.style("opacity", 0);
			});
		var node = svg.append("g").attr("transform", function (d, i) {
			// Set d.x and d.y here so that other elements can use it. d is 
			// expected to be an object here.
			return "translate(90,90)";
		});

		var val = turnoverChart.chartData[0].comparison;
		
		node.append("circle").attr("r", "80")
			.style("fill", "transparent")
			.style("stroke", widgetOpts.textColor ? widgetOpts.textColor : "#007DB8")
			.style("stroke-width", "5px");
		if (val > 0) {
		node.append("polygon").attr("points", "-50,50 0,-10 50,50").style("fill", "green");
		} else {
		node.append("polygon").attr("points", "-50,-10 0,50 50,-10").style("fill", "red");
		}
		node.append("text")
			.attr("text-anchor", "middle")
			.attr("font-size", "50px")
			.text(function (d) {
				return val + "%";
			})
			.style("fill", (widgetOpts.textColor ? widgetOpts.textColor : "#007DB8"))
			.attr("transform", "translate(0,-20)");

	};

	var loadGraph = function () {
		$('#' + widgetOpts.id).css("height", widgetOpts.chartHeight ? widgetOpts.chartHeight : "300px");
		$('#' + widgetOpts.id).css("width", widgetOpts.chartWidth ? widgetOpts.chartWidth : "auto");
		$('#' + widgetOpts.id).css("margin-bottom", "10px");
		$('#' + widgetOpts.id + " .tick line").css("display", "none !important");

		var data = turnoverChart.chartData

		var setStyling = function () {
			setTimeout(function () {
				if (widgetOpts.textColor) {
					$('#' + widgetOpts.id + ' .nvd3 text').css("fill", widgetOpts.textColor);
				}
				if (widgetOpts.xlabelColor) {
					$('#' + widgetOpts.id + ' .nv-x .nvd3 text').css("fill", widgetOpts.xlabelColor);
				}
				if (widgetOpts.ylabelColor) {
					$('#' + widgetOpts.id + ' .nv-y .nvd3 text').css("fill", widgetOpts.ylabelColor);
				}
				if (widgetOpts.fontSize) {
					$('#' + widgetOpts.id + ' .nvd3 text').css("font-size", widgetOpts.fontSize);
				}
				if (widgetOpts.fontFamily) {
					$('#' + widgetOpts.id + ' .nvd3 text').css("font-family", widgetOpts.fontFamily);
				}



			}, 100);
			setTimeout(function () {
				d3.selectAll('#' + widgetOpts.id + ' .nv-bar').each(function (d, i) {

					var bar = d3.select(this);
					bar.select('polygon').remove();
					var height = bar.select('rect').attr("height");
					var width = bar.select('rect').attr("width");
					bar.select('rect').attr('fill', 'transparent');
					bar.append("polygon")
						.attr("points", (width / 2) + ",0 0," + height + " " + width + "," + height);

					if (bar.data()[0].projected === true) {
						bar.select('polygon')
							.attr("stroke-dasharray", "9, 7")
							.attr("stroke-width", "4px")
							.attr("opacity", "0.5")
							.attr("fill", "transparent");
					}


				});
			}, 500);
		};

		nv.addGraph(function () {
			var chart = nv.models.discreteBarChart()
				.margin({
					left: 0
				})
				.x(function (d) {
					return d.Year;
				})
				.y(function (d) {
					return d.value
				})
				.staggerLabels(false)
				.showValues(true)
				.color(widgetOpts.chartColors ? widgetOpts.chartColors : turnoverChart.barclaysColors)
				.showYAxis(false);

			chart.tooltip.contentGenerator(function (key, x, y, e, graph) {
				return '<table><tbody><tr><td class="legend-color-guide"><div style="background-color: ' + key.color + ';"></div></td><td class="key">' + (key.data.projected ? "Projected:" : key.data.Year) + '</td><td class="value">' + d3.format(",.2f")(key.data.value) + '</td></tr></tbody></table>';
			});

			d3.select('#' + widgetOpts.id + ' svg')
				.datum(data)
				.transition().duration(500)
				.call(chart);

			nv.utils.windowResize(function () {
				chart.update()
				setStyling();
			});



			return chart;
		});
		setStyling();


	};

	var processData = function (data) {
		//any data processing required can go in here
		//call the loadGraph function from here to run after data is processed
		//use the dataLineage to get the data in the expected data format

		//dummy data to empty the chart
		var noData = [{
			"key": "",
			"values": [[]]
				}];

		if (widgetOpts.dataLineage) {
			var a = widgetOpts.dataLineage.split("|");
			a.forEach(function (d) {
				data = data[d];
			});
		}
		turnoverChart.chartData = !data || data.length === 0 ? noData : data;
		loadGraph();
		loadDivs();
	}

	var getDataURL = function () {
		if (widgetOpts.api) {
			var custNo = $('#' + widgetOpts.id).data("cust"); //pass this into your API as appropriate
			$.get(widgetOpts.api, function (data) {
				console.log(data);
				try {
					data = $.parseJSON(data);
				} catch (err) {}
				if (widgetOpts.dataLineage) {
					var a = widgetOpts.dataLineage.split("|");
					a.forEach(function (d) {
						data = data[d];
					});
				}
				processData(data)
			}).fail(function () {
				console.log('error');
				processData([])

			});
		}
	};

	var getDataFun = function () {

		turnoverChart.chartData = widget[widgetOpts.api]();
		processData(turnoverChart.chartData)

	};
	if (widgetOpts.URL) {
		getDataURL();
	} else {
		getDataFun();
	}



};