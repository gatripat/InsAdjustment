'use strict';

var balancesChart = balancesChart || {};

balancesChart.barclaysColors = ['rgb(0, 126, 182)', 'darkgrey', 'lightgrey'];

/*create the account listener to listen to when the dropdown is changed*/
balancesChart.accountListener = function (widgetOpts) {
	$('#account-selector-' + widgetOpts.id).unbind();
	$('#account-selector-' + widgetOpts.id).change(function () {
		console.log("channel toggle change detected");
		console.log('text: ' + $('#account-selector-' + widgetOpts.id + ' option:selected').text() + ', val: ' + $("#account-selector-" + widgetOpts.id).val());
		balancesChart.initChart(widgetOpts);
	});
};

balancesChart.initChart = function (widgetOpts) {

	/*first add the svg*/
	d3.select("#" + widgetOpts.id)
		.append("svg:svg");


	/*selector for creating accounts*/
	var createSelector = function () {
		var select = document.createElement("select");
		select.setAttribute("id", "account-selector-" + widgetOpts.id);
		var eElement = document.getElementById(widgetOpts.id);
		eElement.insertBefore(select, eElement.firstChild);

		for (var i = 0; i < balancesChart.custArray.length; i++) {
			var opt = balancesChart.custArray[i].accountID;
			var el = document.createElement("option");
			el.textContent = 'A/N: ' + balancesChart.custArray[i].accountNumber + ' S/C: ' + balancesChart.custArray[i].sortCode;
			el.value = opt;
			select.appendChild(el);
		}
		/*once the dropdown is created initiate the account listener to detect when this changes*/
		balancesChart.accountListener(widgetOpts);
	}

	var loadGraph = function () {
		$('#' + widgetOpts.id).css("height", widgetOpts.chartHeight ? widgetOpts.chartHeight : "300px");
		$('#' + widgetOpts.id).css("width", widgetOpts.chartWidth ? widgetOpts.chartWidth : "auto");
		$('#' + widgetOpts.id).css("margin-bottom", "10px");

		var data = balancesChart.chartData;

		data = data[0].monthlyAverage;

		var setStyling = function () {
			setTimeout(function () {
				if (widgetOpts.textColor) {
					$('#' + widgetOpts.id + ' .nvd3 text').css("fill", widgetOpts.textColor);
				}
				if (widgetOpts.xlabelColor) {
					$('#' + widgetOpts.id + ' .nv-x .nvd3 text').css("fill", widgetOpts.xlabelColor);
				}
				if (widgetOpts.ylabelColor) {
					$('#' + widgetOpts.id + ' .nv-y .nvd3 text').css("fill", widgetOpts.ylabelColor);
				}
				if (widgetOpts.fontSize) {
					$('#' + widgetOpts.id + ' .nvd3 text').css("font-size", widgetOpts.fontSize);
				}
				if (widgetOpts.fontFamily) {
					$('#' + widgetOpts.id + ' .nvd3 text').css("font-family", widgetOpts.fontFamily);
				}
			}, 100);
		};

		nv.addGraph(function () {
			var chart = nv.models.lineChart()
				.margin({
					left: 100
				})
				.x(function (d) {
					return d.month;
				})
				//adjusting, 100% is 1.00, not 100 as it is in the data
				.y(function (d) {
					return d.avgBalance;
				})
				.color(widgetOpts.chartColors ? widgetOpts.chartColors : balancesChart.barclaysColors)
				.useInteractiveGuideline(true);

			chart.xAxis
				.tickFormat(function (d) {
					return d3.time.format('%b')(new Date(0, d, 1))
				});

			chart.xAxis.tickValues(data[0].values.map(function (d) {
				return d.month;
			}));

			chart.yAxis.tickFormat(function (d) {
				return '£' + d3.format(',.2f')(d)
			});

			chart.legend.dispatch.legendClick = function () {
				setStyling();
			};

			d3.select('#' + widgetOpts.id + ' svg')
				.datum(data)
				.transition().duration(500)
				.call(chart);

			nv.utils.windowResize(function () {
				chart.update();
				setStyling();
			});

			return chart;
		});

		setStyling();
	};


	var processCustData = function (custData) {
		if (widgetOpts.dataLineage) {
			var a = widgetOpts.dataLineage.split("|");
			a.forEach(function (d) {
				custData = custData[d];
			});
		}
		balancesChart.custArray = [];
		custData.products.forEach(function (d) {
			if (d.productLevel1 === "DEPOSITS") {
				balancesChart.custArray = balancesChart.custArray.concat(d.accounts);
			}
		});
		balancesChart.custArray.sort(function (a, b) {
			var x = a.primary;
			var y = b.primary;
			return ((x > y) ? -1 : ((x < y) ? 1 : 0));
		});
		console.log(balancesChart.custArray)
		createSelector();
	};

	var processMonthlyData = function (data) {
		var noData = [
			{
				"accountID": 34567,
				"monthlyAverage": [
					{
						"key": "2016",
						"values": [[]]
												}]
										}]
		if (widgetOpts.dataLineage) {
			var a = widgetOpts.dataLineage.split("|");
			a.forEach(function (d) {
				data = data[d];
			});
		}
		balancesChart.chartData = !data || data.length === 0 ? noData : data;
		loadGraph();

	};

	var getDataURL = function () {
		if (widgetOpts.api) {
			/*monthly stats data*/
			var getMonthlyData = function () {

				var accountID = $("#account-selector-" + widgetOpts.id).val()
				console.log('acc ID: ' + accountID);

				//PROD CODE
				var URLconstruct = widgetOpts.api + '/accounts/monthlyStats/' + accountID;

				$.get(URLconstruct, function (data) {

				}).done(function (data) {
					try {
						data = $.parseJSON(data);
					} catch (err) {}
					console.log(data);
					processMonthlyData(data)
				}).fail(function () {
					console.log('fail');
					processMonthlyData([])
				});

			};
			/*Get customer data*/
			var getCustomerData = function () {
				var custNo = $('#' + widgetOpts.id).data("cust");
				$.get(widgetOpts.api + '/customer/' + custNo, function (customers) {
					try {
						customers = $.parseJSON(customers);
					} catch (err) {}
					processCustData(customers);
					getMonthlyData();
				});

			};

			if (!balancesChart.custArray || $("#account-selector-" + widgetOpts.id).length === 0) {
				/*Only need to get the customer data once - don't need to get it each time the dropdown changes */
				getCustomerData();
			} else {
				getMonthlyData();
			}
		}
	};

	var getDataFun = function () {

		/*use functions written by the end application*/
		if (!balancesChart.custArray || $("#account-selector-" + widgetOpts.id).length === 0) {
			var customers = widgets[widgetOpts.api + 'cust']();
			processCustData(customers);
			var accountID = $("#account-selector-" + widgetOpts.id).val()
			balancesChart.chartData = widgets[widgetOpts.api + 'monthly'](accountID);
		} else {
			var accountID = $("#account-selector-" + widgetOpts.id).val()
			console.log('acc ID: ' + accountID);
			balancesChart.chartData = widgets[widgetOpts.api + 'monthly'](accountID);
		}
		processMonthlyData(balancesChart.chartData);
	};



	/*Initiate the get function to get the data depending on wether it will use a URL or dataFunction*/
	if (widgetOpts.URL) {
		getDataURL();
	} else {
		getDataFun();
	}



};