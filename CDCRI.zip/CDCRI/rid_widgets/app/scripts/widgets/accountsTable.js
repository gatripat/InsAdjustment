'use strict';

var accountsTable = {} || {};

accountsTable.initTable = function (widgetOpts) {

	var loadTable = function () {

		var formatRate = function (val) {
			return val + '%';
		}
		var formatBal = function (val) {
			return d3.format(",.2f")(val);
		}
		var formatDate = function (val) {
			var date = new Date(val);
			console.log(date)
			if (isNaN(date.getTime())) {
				return " "
			} else {
				return d3.time.format("%d-%b-%y")(date);
			}
		}

		var data = accountsTable.tableData;
		var columns = [{
			title: 'Account Name',
			field: 'accountName',
			sortable: true
	}, {
			title: 'Type',
			field: 'type',
			sortable: true
	}, {
			title: 'Sort code',
			field: 'sortCode',
			sortable: true
	}, {
			title: 'ACC NO',
			field: 'accountNumber',
			sortable: true
	}, {
			title: 'Currency',
			field: 'currency',
			sortable: true
	}, {
			title: 'Balance',
			field: 'balance',
			sortable: true,
			align: 'right',
			formatter: formatBal
	}, {
			title: 'Limit',
			field: 'limit',
			sortable: true,
			align: 'right'
	}, {
			title: 'Rate',
			field: 'rate',
			sortable: true,
			align: 'right',
			formatter: formatRate
	}, {
			title: 'Maturity',
			field: 'maturity',
			sortable: true,
			align: 'center',
			formatter: formatDate
	}];

		var table = document.createElement('TABLE');
		table.id = "dc-table-" + widgetOpts.id;
		table.setAttribute("data-search", true);
		table.setAttribute("data-pagination", true);
		table.setAttribute("data-sortable", true);
		table.setAttribute("data-show-pagination-switch", false);
		table.setAttribute("data-page-size", 4);

		document.getElementById(widgetOpts.id).appendChild(table);
		$('#dc-table-' + widgetOpts.id).bootstrapTable({
			columns: columns
		});
		
		$('#dc-table-' + widgetOpts.id).bootstrapTable("load", data);

		if (widgetOpts.headerTextColor) {
			$('#' + widgetOpts.id + ' table thead').css('color', widgetOpts.headerTextColor)
		}
		if (widgetOpts.bodyTextColor) {
			$('#' + widgetOpts.id + ' table tbody').css('color', widgetOpts.bodyTextColor);
		};
	};

	var processData = function (data) {
		if (widgetOpts.dataLineage) {
			var a = widgetOpts.dataLineage.split("|");
			a.forEach(function (d) {
				data = data[d];
			});
		}
		accountsTable.tableData = [];
		data.products.forEach(function (d) {
			d.accounts.forEach(function (e) {
				e.type = d.productLevel2;
			});
			var prodLevel = !widgetOpts.productType || widgetOpts.productType === "accounts" ? "DEPOSITS" : "DEBTS";
			if (d.productLevel1 === prodLevel) {
				accountsTable.tableData = accountsTable.tableData.concat(d.accounts);
			}
		});
		accountsTable.tableData.sort(function (a, b) {
			var x = a.primary;
			var y = b.primary;
			return ((x > y) ? -1 : ((x < y) ? 1 : 0));
		});
		loadTable();
	}

	var getDataURL = function () {
		var custNo = $('#' + widgetOpts.id).data("cust");
		$.get(widgetOpts.api + "/customer/" + custNo, function (data) {
			console.log(data);
			try {
				data = $.parseJSON(data);
			} catch (err) {}
			processData(data);
		});
	};

	var getDataFun = function () {
		accountsTable.tableData = widgets[widgetOpts.api]();
		processData(accountsTable.tableData);
	};


	if (widgetOpts.URL) {
		getDataURL();
	} else {
		getDataFun();
	}
};