'use strict';

/**
 * @ngdoc function
 * @name relationshipInsightDocApp.controller:DeveloperCtrl
 * @description
 * # DeveloperCtrl
 * Controller of the relationshipInsightDocApp
 */
angular.module('relationshipInsightDocApp')
	.controller('DataCtrl', function () {

	})

.directive('api', [

        function () {
		return {
			restrict: 'E',
			replace: true,
			templateUrl: 'views/partials/api.html',
			scope: {
				refid: '@',

				name: '@',

				type: '@'
			},
			controller: function ($scope, CONFIG) {

				var dataConfig = CONFIG[CONFIG.build]
				$scope.showData = false;

				if ($scope.type === 'balances') {
					$scope.URL = dataConfig.url + '/accounts/monthlyStats/' + dataConfig.balancesID; //+ '/monthlyStats'
				} else if ($scope.type === 'facilities') {
					$scope.URL = dataConfig.url + '/accounts/overdraftUsage/' + dataConfig.facilitiesID; //+ '/overdraftUsage';
				} else if ($scope.type === 'customer') {
					$scope.URL = dataConfig.url + '/customer/' + dataConfig.custID;
				}

				$.get($scope.URL, function (data) {

					try {
						data = $.parseJSON(data);
					} catch (err) {}
					console.log(data);
					//					loadTable(data);

					$scope.displayData = JSON.stringify(data, null, 2);
					console.log($scope.displayData);

				});




			}
		};
	}]);