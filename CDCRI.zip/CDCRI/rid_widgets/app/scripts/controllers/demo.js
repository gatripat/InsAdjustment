'use strict';

angular.module('relationshipInsightDocApp')
	.controller('DemoCtrl', function ($scope, CONFIG) {

		$scope.dataConfig = CONFIG[CONFIG.build];
		var barclayColours = [
        'rgba(0,56,94, 1)',
        'rgba(0,125,184, 1)',
        'rgba(45,150,68, 1)',
        'rgba(255,190,16,1)',
        'rgba(255,36,0, 1)',
        //'rgba(236,100,0, 1)',
        'rgba(159,0,57, 1)',
        'rgba(177,161,148, 1)',
        'rgba(204,51,51,1)',
        'rgba(114,163,9, 1)',
        'rgba(177,161,148, 0.5)',
        'rgba(0,56,94, 0.5)',
        'rgba(0,125,184, 0.5)',
        'rgba(45,150,68, 0.5)',
        'rgba(255,190,16,0.5)',
        'rgba(236,100,0, 0.5)',
        'rgba(159,0,57, 0.5)',
        'rgba(220,99,10,0.5)',
        'rgba(114,163,9, 0.5)',
        'rgba(204,51,51, 0.5)',
        'rgba(0,174,239, 1)'
    ];

		setTimeout(function () {
			balancesChart.initChart({
				id: 'demoID1',
				URL: true,
				api: $scope.dataConfig.url,
				dataLineage: "",
				textColor: 'rgb(0, 126, 182)',
				xlabelColor: 'rgb(0, 57, 92)',
				ylabelColor: 'rgb(0, 57, 92)'
					//				fontSize: "8px",
					//				chartHeight: "200px",
					//				chartWidth: "300px"
			});

			accountsTable.initTable({
				id: 'demoID2',
				URL: true,
				api: $scope.dataConfig.url,
				dataLineage: "",
				//				bodyTextColor: 'blue',
				headerTextColor: 'rgb(0, 126, 182)'
			});
			
			accountsTable.initTable({
				id: 'demoID4',
				URL: true,
				api: $scope.dataConfig.url,
				dataLineage: "",
				headerTextColor: 'rgb(0, 126, 182)',
				productType: 'facilities'
			});
			overdraftChart.initChart({
				id: 'overdraft1',
				URL: true,
				api: $scope.dataConfig.url,
				dataLineage: "",
				textColor: 'rgb(0, 126, 182)',
				xlabelColor: 'rgb(0, 57, 92)',
				ylabelColor: 'rgb(0, 57, 92)'
			});
			
//			exampleBarChart.initChart({
//				id: 'exampleBar',
//				URL: true,
//				api: "testdata/barChart.json",
//				textColor: 'rgb(0, 126, 182)',
//				xlabelColor: 'rgb(0, 57, 92)',
//				ylabelColor: 'rgb(0, 57, 92)',
//				chartColors: barclayColours
//					//				fontSize: "8px"
//
//			});

			turnoverChart.initChart({
				id: 'example',
				URL: true,
				api: "testdata/turnover.json",
				textColor: 'rgb(0, 126, 182)',
				xlabelColor: 'rgb(0, 57, 92)',
				ylabelColor: 'rgb(0, 57, 92)',
				chartColors: barclayColours
					//				fontSize: "8px"

			});

			examplePieChart.initChart({
						id: 'demoID3',
						URL: true,
						api: $scope.dataConfig.url,
						textColor: 'rgb(0, 126, 182)',
						xlabelColor: 'rgb(0, 57, 92)',
						ylabelColor: 'rgb(0, 57, 92)',
						chartHeight: "350px",
						chartColors: barclayColours
								//				fontSize: "8px"
						});
		},50 );

	})

.directive('demoWidget', [

        function () {
		return {
			restrict: 'E',
			replace: true,
			templateUrl: 'views/demo-widget.html',
			scope: {
				refid: '@',
				chart: '@',
				type: '@',
				custid: '@',
				name: '@'
			},
			link: function () {

			}
		};
	}]);