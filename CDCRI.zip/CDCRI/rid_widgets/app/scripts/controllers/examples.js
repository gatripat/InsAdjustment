'use strict';

/**
 * @ngdoc function
 * @name relationshipInsightDocApp.controller:ExamplesCtrl
 * @description
 * # ExamplesCtrl
 * Controller of the relationshipInsightDocApp
 */
angular.module('relationshipInsightDocApp')
	.controller('ExamplesCtrl', function ($scope, CONFIG) {
		$scope.dataConfig = CONFIG[CONFIG.build];

		$scope.zip = function () {
			var zip = new JSZip();
			zip.file("accountsTable.js", "Hello World\n");
			zip.file("balancesChart.js", "Hello World\n");
//			zip.file("exampleBarChart.js", "Hello World\n");
			zip.file("examplePieChart.js", "Hello World\n");
			zip.file("turnoverChart.js", "Hello World\n");
			zip.file("overdraftChart.js", "Hello World\n");
			var content = zip.generate({
				type: "blob"
			});
			// see FileSaver.js
			saveAs(content, "example.zip");
		};

	})

.directive('widget', [

        function () {
		return {
			restrict: 'E',
			replace: true,
			templateUrl: 'views/widget.html',
			scope: {
				refid: '@',
				chart: '@',
				type: '@',
				custid: '@'
			},
			controller: function ($scope, CONFIG) {
				$scope.dataConfig = CONFIG[CONFIG.build];

				$scope.showOpts = false;
				$scope.initCharts = function () {
					var opts;
					if ($scope.chart === 'balancesChart') {
						opts = {
							id: 'uniqueID1',
							URL: true,
							api: $scope.dataConfig.url,
							dataLineage: "",
							textColor: 'rgb(0, 126, 182)',
							xlabelColor: 'rgb(0, 57, 92)',
							ylabelColor: 'rgb(0, 57, 92)',
							chartHeight: '300px',
							chartWidth: 'auto',
							fontSize: '12px'
						};
						balancesChart.initChart(opts);
						balancesChart.accountListener(opts);
					} else if ($scope.chart === 'accountsTable') {
						opts = {
							id: 'uniqueID2',
							productType:'accounts',
							URL: true,
							api: $scope.dataConfig.url,
							dataLineage: "",
							bodyTextColor: 'black',
							headerTextColor: 'rgb(0, 126, 182)',
							chartHeight: 'auto'
						}
						accountsTable.initTable(opts);
					} else if ($scope.chart === 'turnoverChart') {
						opts = {
							id: 'uniqueID4',
							URL: true,
							api: "testdata/turnover.json",
							textColor: 'rgb(0, 126, 182)',
							xlabelColor: 'rgb(0, 57, 92)',
							chartHeight: '300px',
							chartWidth: 'auto',
							fontSize: '12px'
							//							chartColors: barclayColours
						}
						turnoverChart.initChart(opts);
					} else if ($scope.chart === 'overdraftChart') {
						opts = {
							id: 'uniqueID3',
							URL: true,
							api: $scope.dataConfig.url,
							dataLineage: "",
							textColor: 'rgb(0, 126, 182)',
							xlabelColor: 'rgb(0, 57, 92)',
							ylabelColor: 'rgb(0, 57, 92)',
							fontSize: '12px'
						}
						$scope.setOpts = opts;
						overdraftChart.initChart(opts);
						overdraftChart.accountListener(opts);
						
					}
					$scope.configOpts = opts;
					
				}
				setTimeout(function () {
					$scope.initCharts();
				}, 100);



				$scope.updateChart = function () {

					if ($scope.chart === 'balancesChart') {
						balancesChart.initChart($scope.configOpts);
						balancesChart.accountListener($scope.configOpts);
					} else if ($scope.chart === 'accountsTable') {
						accountsTable.initTable($scope.configOpts);
					} else if ($scope.chart === 'turnoverChart') {
						turnoverChart.initChart($scope.configOpts);
					} else if ($scope.chart === 'overdraftChart') {
						overdraftChart.initChart($scope.configOpts);
						overdraftChart.accountListener($scope.configOpts);
					}
				};

				$scope.copyOpts = function () {
					window.prompt("Copy to clipboard: Ctrl+C, Enter", JSON.stringify($scope.configOpts));
				};

			}
		};
				}]);