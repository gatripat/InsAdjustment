'use strict';

/**
 * @ngdoc function
 * @name relationshipInsightDocApp.controller:DeveloperCtrl
 * @description
 * # DeveloperCtrl
 * Controller of the relationshipInsightDocApp
 */
angular.module('relationshipInsightDocApp')
	.controller('DeveloperCtrl', function () {
		setTimeout(function () {
			exampleBarChart.initChart({
				id: 'example',
				URL: true,
				api: "testdata/barChart.json"
			});
		}, 100);
	});