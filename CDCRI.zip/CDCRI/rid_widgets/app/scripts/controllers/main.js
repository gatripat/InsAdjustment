'use strict';

/**
 * @ngdoc function
 * @name relationshipInsightDocApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the relationshipInsightDocApp
 */

var api1 = {
	url: 'http://9.118.9.22:8000/datapi/api',
	custID: '8798798',
	balancesID: '34567/monthlyStats',
	facilitiesID: '34567'
};

var api2 = {
	url: 'http://9.118.9.22:8000/datapi/api',
	custID: '501',
	balancesID: '228857511',
	facilitiesID: '34567'
};

var api3 = {
	url: 'http://9.195.66.133:8080/datapi/api',
	custID: '501',
	balancesID: '228857511',
	facilitiesID: '34567'
}

angular.module('relationshipInsightDocApp')
	.constant('CONFIG', {
		build: 'test',
		test: {
			url: 'testdata',
			custID: 'custCollectionApi.json',
			balancesID: '34567',
			facilitiesID: '34567'
		},
		api: api2
	})

.controller('MainCtrl', function ($scope) {

	
	$scope.zip = function() {
		var zip = new JSZip();
		zip.file("accountsTable.js", "Hello World\n");
		zip.file("balancesChart.js", "Hello World\n");
		zip.file("exampleBarChart.js", "Hello World\n");
		zip.file("examplePieChart.js", "Hello World\n");
		zip.file("turnoverChart.js", "Hello World\n");
		zip.file("overdraftChart.js", "Hello World\n");
		var content = zip.generate({
			type: "blob"
		});
		// see FileSaver.js
		saveAs(content, "example.zip");
	};
})

.directive('nav', [
        function () {
		return {
			restrict: 'E',
			replace: true,
			templateUrl: 'views/partials/nav.html',
			controller: function ($anchorScroll, $location, $scope) {
				$scope.gotoAnchor = function (x) {
					$scope.switch = 1;
					var newHash = x;
					console.log(x);
					if ($location.hash() !== newHash) {
						// set the $location.hash to `newHash` and
						// $anchorScroll will automatically scroll to it
						$location.hash(x);
					} else {
						// call $anchorScroll() explicitly,
						// since $location.hash hasn't changed
						$anchorScroll();
					}
				};
			}
		};
	}]);